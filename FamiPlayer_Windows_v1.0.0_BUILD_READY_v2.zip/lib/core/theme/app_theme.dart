import 'package:flutter/material.dart';
import 'app_colors.dart';
import 'app_typography.dart';

enum AppThemeMode { obsidian, amoled, light, system }
enum AppAccentColor { cyan, amber, emerald, violet }

class AppTheme {
  static Color getAccentColor(AppAccentColor option) {
    switch (option) {
      case AppAccentColor.cyan:
        return AppColors.cyanPrimary;
      case AppAccentColor.amber:
        return AppColors.amberPrimary;
      case AppAccentColor.emerald:
        return AppColors.emeraldPrimary;
      case AppAccentColor.violet:
        return AppColors.violetPrimary;
    }
  }

  static Color getAccentGlow(AppAccentColor option) {
    switch (option) {
      case AppAccentColor.cyan:
        return AppColors.cyanGlow;
      case AppAccentColor.amber:
        return AppColors.amberGlow;
      case AppAccentColor.emerald:
        return AppColors.emeraldGlow;
      case AppAccentColor.violet:
        return AppColors.violetGlow;
    }
  }

  static Color getColor(AppAccentColor option) => getAccentColor(option);

  static ThemeData build({
    required AppThemeMode mode,
    required AppAccentColor accent,
    String? fontFamily,
  }) {
    return getThemeData(
      mode: mode,
      accent: accent,
      isRtl: fontFamily == 'Vazirmatn',
      systemBrightness: WidgetsBinding.instance.platformDispatcher.platformBrightness,
    );
  }

  static ThemeData getThemeData({
    required AppThemeMode mode,
    required AppAccentColor accent,
    required bool isRtl,
    required Brightness systemBrightness,
  }) {
    final bool isDark = mode == AppThemeMode.obsidian ||
        mode == AppThemeMode.amoled ||
        (mode == AppThemeMode.system && systemBrightness == Brightness.dark);

    final bool isAmoled = mode == AppThemeMode.amoled;
    final Color primaryAccent = getAccentColor(accent);

    final Color bgColor = isDark
        ? (isAmoled ? AppColors.amoledBackground : AppColors.obsidian)
        : AppColors.lightBackground;

    final Color surfaceColor = isDark
        ? (isAmoled ? AppColors.amoledSurface : AppColors.surface)
        : AppColors.lightSurface;

    final Color cardColor = isDark ? AppColors.surfaceCard : AppColors.lightSurfaceCard;
    final Color borderColor = isDark ? AppColors.border : AppColors.lightBorder;

    return ThemeData(
      useMaterial3: true,
      brightness: isDark ? Brightness.dark : Brightness.light,
      scaffoldBackgroundColor: bgColor,
      colorScheme: ColorScheme(
        brightness: isDark ? Brightness.dark : Brightness.light,
        primary: primaryAccent,
        onPrimary: Colors.black,
        secondary: primaryAccent,
        onSecondary: Colors.black,
        error: AppColors.error,
        onError: Colors.white,
        surface: surfaceColor,
        onSurface: isDark ? AppColors.textPrimary : AppColors.textLightPrimary,
        outline: borderColor,
      ),
      cardTheme: CardThemeData(
        color: cardColor,
        elevation: 0,
        shape: RoundedCornerShape(16.0, borderColor),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: AppColors.surfaceModal,
        elevation: 16,
        shape: RoundedCornerShape(24.0, borderColor),
      ),
      textTheme: AppTypography.getTextTheme(isRtl: isRtl, isDark: isDark),
      sliderTheme: SliderThemeData(
        activeTrackColor: primaryAccent,
        inactiveTrackColor: Colors.white.withOpacity(0.24),
        thumbColor: primaryAccent,
        trackHeight: 4.0,
        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6.0),
        overlayShape: const RoundSliderOverlayShape(overlayRadius: 14.0),
      ),
      scrollbarTheme: ScrollbarThemeData(
        thumbColor: MaterialStateProperty.all(borderColor.withOpacity(0.8)),
        radius: const Radius.circular(8),
        thickness: MaterialStateProperty.all(6),
      ),
    );
  }
}

class RoundedCornerShape extends RoundedRectangleBorder {
  RoundedCornerShape(double radius, Color borderColor)
      : super(
          borderRadius: BorderRadius.circular(radius),
          side: BorderSide(color: borderColor, width: 1.0),
        );
}
