import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:crypto/crypto.dart' hide Hmac;
import 'package:cryptography/cryptography.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/file_utils.dart';
import 'package:path/path.dart' as p;

class VaultSecurityService {
  static const String _prefVaultPinHash = 'fami_vault_pin_hash';
  static const String _prefVaultPinSalt = 'fami_vault_pin_salt';
  static const int _pbkdf2Iterations = 100000;

  final AesGcm _aesGcm = AesGcm.with256bits();

  Future<bool> isVaultConfigured() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.containsKey(_prefVaultPinHash) &&
        (prefs.getString(_prefVaultPinHash)?.isNotEmpty ?? false);
  }

  Future<bool> setPin(String pin) async {
    if (pin.length < 4) return false;
    final prefs = await SharedPreferences.getInstance();
    final salt = _generateSecureSalt();
    final hash = await _hashPinWithPbkdf2(pin, salt);
    await prefs.setString(_prefVaultPinSalt, base64Encode(salt));
    await prefs.setString(_prefVaultPinHash, hash);
    return true;
  }

  Future<bool> verifyPin(String pin) async {
    final prefs = await SharedPreferences.getInstance();
    final savedHash = prefs.getString(_prefVaultPinHash);
    final savedSaltBase64 = prefs.getString(_prefVaultPinSalt);
    if (savedHash == null || savedSaltBase64 == null) return false;

    final salt = base64Decode(savedSaltBase64);
    final computedHash = await _hashPinWithPbkdf2(pin, salt);
    return _constantTimeCompare(computedHash, savedHash);
  }

  Future<File> encryptAndStoreFile({
    required File sourceFile,
    required String pin,
    required String originalName,
    bool shredOriginal = false,
  }) async {
    final vaultDir = await FileUtils.getVaultDirectory();
    final secretKey = await _deriveKeyFromPin(pin);
    final fileBytes = await sourceFile.readAsBytes();

    final secretBox = await _aesGcm.encrypt(
      fileBytes,
      secretKey: secretKey,
    );

    final encryptedFileName =
        '${DateTime.now().millisecondsSinceEpoch}_${p.basenameWithoutExtension(originalName)}.famienc';
    final encryptedFile = File(p.join(vaultDir.path, encryptedFileName));

    // Structure: [Nonce 12 bytes] + [Mac 16 bytes] + [Ciphertext]
    final outputBytes = BytesBuilder();
    outputBytes.add(secretBox.nonce);
    outputBytes.add(secretBox.mac.bytes);
    outputBytes.add(secretBox.cipherText);

    await encryptedFile.writeAsBytes(outputBytes.toBytes(), flush: true);

    if (shredOriginal) {
      await secureShredFile(sourceFile);
    }

    return encryptedFile;
  }

  Future<Uint8List> decryptFile({
    required File encryptedFile,
    required String pin,
  }) async {
    final secretKey = await _deriveKeyFromPin(pin);
    final allBytes = await encryptedFile.readAsBytes();

    if (allBytes.length < 28) {
      throw Exception('Invalid encrypted file format or corrupted header.');
    }

    final nonce = allBytes.sublist(0, 12);
    final macBytes = allBytes.sublist(12, 28);
    final cipherText = allBytes.sublist(28);

    final secretBox = SecretBox(
      cipherText,
      nonce: nonce,
      mac: Mac(macBytes),
    );

    final decryptedBytes = await _aesGcm.decrypt(
      secretBox,
      secretKey: secretKey,
    );

    return Uint8List.fromList(decryptedBytes);
  }

  /// Performs multi-pass file overwrite and deletion.
  ///
  /// Note on Solid State Drives (SSDs) and Flash Storage:
  /// Modern SSDs employ Wear Leveling and Flash Translation Layer (FTL) controllers
  /// that dynamically remap physical storage blocks. Software-level overwriting provides
  /// sanitization on traditional magnetic media (HDDs), but cannot guarantee that underlying
  /// physical NAND flash blocks on an SSD are overwritten without hardware-level TRIM/Secure Erase.
  Future<void> secureShredFile(File file) async {
    if (!await file.exists()) return;
    try {
      final length = await file.length();
      final random = Random.secure();
      final randomBytes = Uint8List(length);
      for (int i = 0; i < length; i++) {
        randomBytes[i] = random.nextInt(256);
      }

      // Overwrite pass 1: Random cryptographically secure bytes
      final sink1 = file.openWrite(mode: FileMode.writeOnly);
      sink1.add(randomBytes);
      await sink1.flush();
      await sink1.close();

      // Overwrite pass 2: Zeroes
      final zeroBytes = Uint8List(length);
      final sink2 = file.openWrite(mode: FileMode.writeOnly);
      sink2.add(zeroBytes);
      await sink2.flush();
      await sink2.close();

      // Finally remove file entry from filesystem
      await file.delete();
    } catch (_) {
      // Fallback standard delete if direct overwriting encounters locks
      if (await file.exists()) {
        await file.delete();
      }
    }
  }

  List<int> _generateSecureSalt() {
    final random = Random.secure();
    return List<int>.generate(16, (_) => random.nextInt(256));
  }

  Future<String> _hashPinWithPbkdf2(String pin, List<int> salt) async {
    final pbkdf2 = Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: _pbkdf2Iterations,
      bits: 256,
    );
    final key = await pbkdf2.deriveKey(
      secretKey: SecretKey(utf8.encode(pin)),
      nonce: salt,
    );
    final bytes = await key.extractBytes();
    return base64Encode(bytes);
  }

  Future<SecretKey> _deriveKeyFromPin(String pin) async {
    final prefs = await SharedPreferences.getInstance();
    final saltBase64 = prefs.getString(_prefVaultPinSalt) ?? '';
    final salt = saltBase64.isNotEmpty
        ? base64Decode(saltBase64)
        : _generateSecureSalt();

    final pbkdf2 = Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: _pbkdf2Iterations,
      bits: 256,
    );

    return await pbkdf2.deriveKey(
      secretKey: SecretKey(utf8.encode(pin)),
      nonce: salt,
    );
  }

  bool _constantTimeCompare(String a, String b) {
    if (a.length != b.length) return false;
    int result = 0;
    for (int i = 0; i < a.length; i++) {
      result |= a.codeUnitAt(i) ^ b.codeUnitAt(i);
    }
    return result == 0;
  }
}
