#pragma once

#include <windows.h>

#include <functional>
#include <memory>
#include <string>

// A class that abstracts the details of creating and managing a Win32 window.
class Win32Window {
 public:
  struct Point {
    unsigned int x;
    unsigned int y;
    Point(unsigned int x, unsigned int y) : x(x), y(y) {}
  };

  struct Size {
    unsigned int width;
    unsigned int height;
    Size(unsigned int width, unsigned int height)
        : width(width), height(height) {}
  };

  Win32Window();
  virtual ~Win32Window();

  // Creates a Win32 window with the given properties.
  bool Create(const std::wstring& title, const Point& origin, const Size& size);

  // Shows the current window.
  bool Show();

  // Releases OS resources associated with window.
  void Destroy();

  // Inserts |content| into the window tree.
  void SetChildContent(HWND content);

  // Returns the backing Window handle to enable clients to set capture and other
  // window attributes.
  HWND GetHandle() const;

  // If true, closing this window will result in the application exiting.
  void SetQuitOnClose(bool quit_on_close);

  // Return a RECT of the bounds of this window in client coordinates.
  RECT GetClientArea() const;

 protected:
  // Processes and routes salient window messages for mouse handling,
  // size changes and any messages that Flutter may also look at.
  virtual LRESULT MessageHandler(HWND window, UINT const message,
                                 WPARAM const wparam,
                                 LPARAM const lparam) noexcept;

  // Called when CreateAndShow completes, allows subclass to perform any
  // additional initialization.
  virtual bool OnCreate();

  // Called when Destroy is called.
  virtual void OnDestroy();

 private:
  friend class WindowClassRegistrar;

  // OS callback called by message pump.
  static LRESULT CALLBACK WndProc(HWND const window, UINT const message,
                                  WPARAM const wparam,
                                  LPARAM const lparam) noexcept;

  // Retrieves a class instance pointer for |window|
  static Win32Window* GetThisFromHandle(HWND const window) noexcept;

  // Window handle.
  HWND window_handle_ = nullptr;

  // Child window hosted by this window.
  HWND child_content_ = nullptr;

  // Flag indicating whether window destruction should quit the process.
  bool quit_on_close_ = false;
};
