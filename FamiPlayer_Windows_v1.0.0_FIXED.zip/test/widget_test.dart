import 'package:flutter_test/flutter_test.dart';
import 'package:fami_player/core/localization/app_localizations.dart';
import 'package:fami_player/core/constants/app_constants.dart';
import 'package:fami_player/core/utils/formatters.dart';
import 'package:fami_player/core/utils/media_type_detector.dart';
import 'package:fami_player/services/equalizer_service.dart';

void main() {
  test('AppConstants contains correct defaults', () {
    expect(AppConstants.appName, 'Fami Player');
    expect(AppConstants.playbackSpeeds.contains(1.0), true);
    expect(AppConstants.equalizerFrequencies.length, 10);
  });

  test('Formatters formats duration accurately', () {
    const duration = Duration(minutes: 3, seconds: 45);
    expect(Formatters.formatDuration(duration), '03:45');
    const longDuration = Duration(hours: 1, minutes: 20, seconds: 5);
    expect(Formatters.formatDuration(longDuration), '01:20:05');
  });

  test('AppLanguage supported properly', () {
    expect(AppLanguage.english.code, 'en');
    expect(AppLanguage.persian.code, 'fa');
    expect(AppLanguage.arabic.code, 'ar');
  });

  test('MediaTypeDetector correctly classifies video, audio and streaming', () {
    expect(MediaTypeDetector.detectFromExtension('.mp4'), MediaType.video);
    expect(MediaTypeDetector.detectFromExtension('.mkv'), MediaType.video);
    expect(MediaTypeDetector.detectFromExtension('.mp3'), MediaType.audio);
    expect(MediaTypeDetector.detectFromExtension('.flac'), MediaType.audio);
    expect(MediaTypeDetector.detectFromExtension('.jpg'), MediaType.photo);
    expect(MediaTypeDetector.detectFromUrl('https://example.com/live/stream.m3u8'), MediaType.stream);
  });

  test('EqualizerService presets have 10 bands', () {
    final eq = EqualizerService();
    expect(eq.bandGains.length, 10);
    eq.applyPreset(EqualizerPreset.bassBoost);
    expect(eq.bandGains.first, greaterThan(0));
    eq.reset();
    expect(eq.bandGains.every((g) => g == 0.0), true);
  });
}

