# Fami Player — Windows Desktop Media Engine

Fami Player is a professional, modern, hardware-accelerated desktop media player and media manager built exclusively for **Windows 10** and **Windows 11 (64-bit)**.

---

## 🌟 Key Capabilities & Architecture

- **High-Performance Playback Engine**: Powered by `media_kit` (backed by `libmpv`) with Direct3D11 / DXVA2 GPU hardware decoding for smooth 4K/8K HDR video playback.
- **Extensive Codec Support**: MKV, MP4, WebM, AVI, MOV, FLAC, MP3, AAC, OGG, WAV, HLS (M3U8), and direct HTTP/HTTPS live streams.
- **10-Band Equalizer**: Real-time multi-band equalizer with presets (Rock, Pop, Classical, Jazz, Bass Boost, Vocal, Cinema).
- **Private Vault**: Hardware-grade AES-256 GCM encrypted storage with PIN protection to safeguard private media.
- **Multilingual & RTL**: Fully localized for English, Persian (فارسی), and Arabic (العربية) with native bidirectional layout support.
- **Windows Integration**: Windows 11 Fluent dark styling, custom title bar, single-instance mutex, and system tray integration.

---

## 🚀 Building on Windows

### Prerequisites
1. **Windows 10 / 11 64-bit**
2. **Flutter SDK** (3.22.0 or newer)
3. **Visual Studio 2022** (with "Desktop development with C++" workload installed)
4. **Inno Setup 6** (for building the installer `.exe`)

### Commands

```powershell
# 1. Navigate to the project directory
cd fami_player_windows

# 2. Get dependencies
flutter pub get

# 3. Run in Desktop Debug mode
flutter run -d windows

# 4. Build optimized Release executable
flutter build windows --release
```

The compiled release package will be located at:
`build/windows/x64/runner/Release/`

---

## 📦 Creating the Installer

To compile the single-file setup installer (`FamiPlayer_Setup_v1.0.0.exe`):

1. Open `installer/fami_player_setup.iss` in **Inno Setup Compiler**.
2. Click **Build > Compile** (or run `iscc installer/fami_player_setup.iss`).
3. Output executable will be in `installer/output/FamiPlayer_Setup_v1.0.0.exe`.
