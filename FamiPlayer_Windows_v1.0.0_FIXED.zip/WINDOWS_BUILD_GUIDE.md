# Fami Player — Windows Build & Deployment Guide

This document outlines the step-by-step instructions for building, packaging, and deploying **Fami Player** on a **Windows 10 / Windows 11 (64-bit)** development environment.

---

## 1. Prerequisites & Environment Setup

### A. Windows Operating System
* Windows 10 (version 1809 or higher) or Windows 11 (64-bit architecture)
* Developer Mode enabled in Windows Settings (*Settings > Update & Security / System > For Developers > Developer Mode*).

### B. Visual Studio 2022
* Install **Visual Studio Community/Professional 2022** (version 17.0+).
* During installation, check the workload:
  * **Desktop development with C++**
* Verify that the following individual components are checked:
  * *MSVC v143 - VS 2022 C++ x64/x86 build tools*
  * *Windows 10 SDK / Windows 11 SDK (10.0.19041.0 or higher)*
  * *C++ CMake tools for Windows*
  * *C++ ATL for latest v143 build tools*

### C. Flutter SDK
* Install Flutter 3.19.0 or newer with Windows desktop support:
  ```powershell
  # Check Flutter setup
  flutter --version
  flutter doctor
  ```
* Enable Windows desktop development in Flutter:
  ```powershell
  flutter config --enable-windows-desktop
  ```

### D. Inno Setup Compiler (For creating the Installer)
* Download and install **Inno Setup 6** (https://jrsoftware.org/isdl.php).
* Ensure `ISCC.exe` is added to your system `PATH` (typically `C:\Program Files (x86)\Inno Setup 6`).

---

## 2. Project Setup & Dependency Installation

1. Clone or transfer the `fami_player_windows` project folder to your Windows machine:
   ```powershell
   cd path\to\fami_player_windows
   ```

2. Fetch all Dart and Flutter packages:
   ```powershell
   flutter pub get
   ```

3. Verify dependencies and configurations:
   ```powershell
   flutter analyze
   ```

---

## 3. Running in Development Mode

To run Fami Player with hot reload and live debugging in Windows:

```powershell
flutter run -d windows
```

### Useful Debug Flags
* Run with verbose engine logs:
  ```powershell
  flutter run -d windows -v
  ```

---

## 4. Compiling the Production Release Executable

To compile the high-performance, optimized 64-bit Windows release binary:

```powershell
flutter build windows --release
```

### Build Artifacts Output Directory
Upon successful compilation, the release build is generated at:
```
build\windows\x64\runner\Release\
```

This folder contains:
* `fami_player.exe` — The main executable
* `flutter_windows.dll` — Flutter engine runtime
* `mpv-2.dll` / `libmpv` — Hardware-accelerated media engine binaries
* `data/` — Bundled Flutter assets, fonts, and icons
* Plugin DLLs (`window_manager.dll`, `desktop_drop.dll`, `tray_manager.dll`, `sqlite3.dll`, etc.)

---

## 5. Creating the Setup Installer (Inno Setup)

An Inno Setup installer script is included in `installer/fami_player_setup.iss`.

### Compiling via GUI:
1. Open `Inno Setup Compiler`.
2. Open `installer\fami_player_setup.iss`.
3. Press **F9** or select **Build > Compile**.

### Compiling via Command Line:
```powershell
iscc.exe installer\fami_player_setup.iss
```

### Installer Output:
The generated single-file setup wizard is placed in:
```
dist\FamiPlayer_v1.0.0_Setup.exe
```

---

## 6. Architecture & Hardware Acceleration Notes

* **Direct3D 11 & DXVA2 Hardware Decoding**: The player engine automatically leverages Direct3D 11 and DXVA2 on modern NVIDIA, AMD, and Intel GPUs.
* **Single Instance Protection**: A Windows named mutex (`FamiPlayer_SingleInstance_Mutex`) prevents multiple duplicate instances from opening concurrently.
* **Security & Private Vault**: Vault files are encrypted using 256-bit AES-GCM with PBKDF2 (100,000 iterations). Deleting items performs a multi-pass software disk wipe before removal (Note: software overwrite cannot guarantee physical flash erasure on SSDs due to Wear Leveling/FTL controllers).
