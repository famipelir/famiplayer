# Fami Player — Production Release Verification Checklist

This checklist must be executed prior to packaging and publishing each production release of **Fami Player for Windows**.

---

## 1. Environment & Pre-Build Checks
- [x] **Target Architecture**: Confirmed Windows 64-bit (x64) target.
- [x] **Flutter SDK**: Flutter 3.19.0+ configured with Windows desktop support.
- [x] **Visual Studio**: Visual Studio 2022 C++ desktop tools and Windows SDK 10/11 installed.
- [x] **Clean Workspace**: `flutter clean && flutter pub get` executed cleanly.

## 2. Windows Native & Runner Checks
- [x] **Single-Instance Mutex**: `FamiPlayer_SingleInstance_Mutex` verified in `windows/runner/main.cpp`.
- [x] **C++ Runner Files**: `flutter_window.h/.cpp`, `win32_window.h/.cpp`, `utils.h/.cpp`, `resource.h`, `Runner.rc`, `runner.exe.manifest` all present and linked.
- [x] **CMake Configuration**: `dwmapi.lib` linked for custom Windows 11 title bar support.
- [x] **Application Metadata**: Name set to `Fami Player`, Publisher `Fami`, Identifier `com.fami.player`.

## 3. Media Playback & Engine Quality
- [x] **Local Video Playback**: Tested with MP4 (H.264 / H.265), MKV, WebM, MOV, and AVI containers.
- [x] **Local Audio Playback**: Tested with FLAC, MP3, AAC, WAV, and OGG formats.
- [x] **Network Streams**: Validated direct MP4 URLs and live HLS (M3U8) streams.
- [x] **Hardware Acceleration**: Verified D3D11 / DXVA2 GPU decoding capability.
- [x] **Audio Equalizer**: 10-band slider controls and 8 presets (Rock, Pop, Jazz, Classical, Bass Boost, Vocal, Movie, Flat) functioning.
- [x] **Playback Controls**: A-B Loop, frame-by-frame stepping (`[` and `]`), speed selector (0.25x–4.0x), aspect ratio modes, screenshot capture verified.

## 4. Security & Private Vault
- [x] **Encryption Algorithm**: Verified AES-256-GCM authenticated cipher with 12-byte random nonce and 16-byte MAC.
- [x] **Key Derivation**: Verified PBKDF2 with 100,000 iterations, HMAC-SHA256, and secure 16-byte random salt (`Random.secure()`).
- [x] **Constant-Time PIN Verification**: Constant-time comparison implemented to mitigate side-channel timing attacks.
- [x] **Secure Disk Wipe (Shredder)**: Multi-pass file overwrites implemented before unlinking deleted or imported vault media (with documented SSD wear leveling considerations).
- [x] **No Hardcoded Secrets**: Zero hardcoded passwords, tokens, API keys, or paths in the codebase.

## 5. UI, Localization & Desktop UX
- [x] **Desktop Form Factor**: Window minimum size enforced at 960x600, default at 1280x800.
- [x] **Drag & Drop**: Native media drag & drop verified across the window.
- [x] **Keyboard Shortcuts**: Space (Play/Pause), Left/Right (Seek), Up/Down (Volume), F (Fullscreen), M (Mute), Esc (Exit fullscreen), `[` / `]` (Frame step).
- [x] **Localization Persistence**: English (LTR), Persian (فارسی - RTL), and Arabic (العربية - RTL) switchable dynamically and persisted in `SharedPreferences`.
- [x] **Themes & Colors**: Obsidian Dark, AMOLED Pure Black, and Light themes switchable with 4 custom accent colors.

## 6. Installer & Distribution
- [x] **Inno Setup Script**: `installer/fami_player_setup.iss` paths configured for `build\windows\x64\runner\Release\`.
- [x] **License File**: `LICENSE` file present at project root.
- [x] **Uninstaller**: Desktop shortcut and Start Menu shortcuts generated with clean uninstaller registration.
