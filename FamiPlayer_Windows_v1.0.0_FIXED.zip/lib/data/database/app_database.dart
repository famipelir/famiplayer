import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import '../../core/utils/file_utils.dart';
import '../models/media_item_model.dart';
import '../models/playlist_model.dart';

class AppDatabase {
  static AppDatabase? _instance;
  static Database? _database;

  AppDatabase._();

  static AppDatabase get instance => _instance ??= AppDatabase._();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    sqfliteFfiInit();
    final databaseFactory = databaseFactoryFfi;

    final appSupportDir = await FileUtils.getAppSupportDirectory();
    final dbPath = p.join(appSupportDir.path, 'fami_player.db');

    return await databaseFactory.openDatabase(
      dbPath,
      options: OpenDatabaseOptions(
        version: 1,
        onCreate: (db, version) async {
          await db.execute('''
            CREATE TABLE media_items (
              id TEXT PRIMARY KEY,
              path TEXT UNIQUE,
              title TEXT,
              artist TEXT,
              album TEXT,
              genre TEXT,
              mediaType INTEGER,
              durationMs INTEGER,
              fileSizeBytes INTEGER,
              width INTEGER,
              height INTEGER,
              lastPlayedPositionMs INTEGER,
              dateAdded INTEGER,
              lastPlayedAt INTEGER,
              isFavorite INTEGER,
              thumbnailPath TEXT
            )
          ''');

          await db.execute('''
            CREATE TABLE playlists (
              id TEXT PRIMARY KEY,
              title TEXT,
              description TEXT,
              createdAt INTEGER,
              updatedAt INTEGER,
              mediaItemIds TEXT
            )
          ''');

          await db.execute('''
            CREATE TABLE history (
              id TEXT PRIMARY KEY,
              mediaItemId TEXT,
              title TEXT,
              path TEXT,
              positionMs INTEGER,
              durationMs INTEGER,
              playedAt INTEGER
            )
          ''');

          await db.execute('''
            CREATE TABLE vault_items (
              id TEXT PRIMARY KEY,
              originalName TEXT,
              encryptedPath TEXT,
              fileSizeBytes INTEGER,
              mediaTypeIndex INTEGER,
              dateEncrypted INTEGER
            )
          ''');

          await db.execute('''
            CREATE TABLE monitored_folders (
              id TEXT PRIMARY KEY,
              folderPath TEXT UNIQUE,
              dateAdded INTEGER
            )
          ''');
        },
      ),
    );
  }

  // Media Items Queries
  Future<int> insertMediaItem(MediaItemModel item) async {
    final db = await database;
    return await db.insert(
      'media_items',
      item.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<MediaItemModel>> getAllMediaItems() async {
    final db = await database;
    final maps = await db.query('media_items', orderBy: 'dateAdded DESC');
    return maps.map((m) => MediaItemModel.fromMap(m)).toList();
  }

  Future<List<MediaItemModel>> getMediaItemsByType(int mediaTypeIndex) async {
    final db = await database;
    final maps = await db.query(
      'media_items',
      where: 'mediaType = ?',
      whereArgs: [mediaTypeIndex],
      orderBy: 'title ASC',
    );
    return maps.map((m) => MediaItemModel.fromMap(m)).toList();
  }

  Future<List<MediaItemModel>> getFavoriteItems() async {
    final db = await database;
    final maps = await db.query(
      'media_items',
      where: 'isFavorite = 1',
      orderBy: 'title ASC',
    );
    return maps.map((m) => MediaItemModel.fromMap(m)).toList();
  }

  Future<List<MediaItemModel>> getRecentlyPlayedItems({int limit = 15}) async {
    final db = await database;
    final maps = await db.query(
      'media_items',
      where: 'lastPlayedAt IS NOT NULL',
      orderBy: 'lastPlayedAt DESC',
      limit: limit,
    );
    return maps.map((m) => MediaItemModel.fromMap(m)).toList();
  }

  Future<int> updateMediaItem(MediaItemModel item) async {
    final db = await database;
    return await db.update(
      'media_items',
      item.toMap(),
      where: 'id = ?',
      whereArgs: [item.id],
    );
  }

  Future<int> updatePlaybackPosition(String id, int positionMs) async {
    final db = await database;
    return await db.update(
      'media_items',
      {
        'lastPlayedPositionMs': positionMs,
        'lastPlayedAt': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> toggleFavorite(String id, bool isFavorite) async {
    final db = await database;
    return await db.update(
      'media_items',
      {'isFavorite': isFavorite ? 1 : 0},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // Playlists
  Future<List<PlaylistModel>> getPlaylists() async {
    final db = await database;
    final maps = await db.query('playlists', orderBy: 'updatedAt DESC');
    return maps.map((m) => PlaylistModel.fromMap(m)).toList();
  }

  Future<int> savePlaylist(PlaylistModel playlist) async {
    final db = await database;
    return await db.insert(
      'playlists',
      playlist.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<int> deletePlaylist(String id) async {
    final db = await database;
    return await db.delete('playlists', where: 'id = ?', whereArgs: [id]);
  }

  // History Queries
  Future<List<HistoryItemModel>> getHistory({int limit = 50}) async {
    final db = await database;
    final maps = await db.query('history', orderBy: 'playedAt DESC', limit: limit);
    return maps.map((m) => HistoryItemModel.fromMap(m)).toList();
  }

  Future<int> addHistory(HistoryItemModel item) async {
    final db = await database;
    return await db.insert(
      'history',
      item.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<int> clearHistory() async {
    final db = await database;
    return await db.delete('history');
  }

  // Vault Items Queries
  Future<List<VaultItemModel>> getVaultItems() async {
    final db = await database;
    final maps = await db.query('vault_items', orderBy: 'dateEncrypted DESC');
    return maps.map((m) => VaultItemModel.fromMap(m)).toList();
  }

  Future<int> saveVaultItem(VaultItemModel item) async {
    final db = await database;
    return await db.insert(
      'vault_items',
      item.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<int> deleteVaultItem(String id) async {
    final db = await database;
    return await db.delete('vault_items', where: 'id = ?', whereArgs: [id]);
  }

  // Monitored Folders
  Future<List<String>> getMonitoredFolders() async {
    final db = await database;
    final maps = await db.query('monitored_folders');
    return maps.map((m) => m['folderPath'] as String).toList();
  }

  Future<int> addMonitoredFolder(String folderPath) async {
    final db = await database;
    return await db.insert(
      'monitored_folders',
      {
        'id': folderPath.hashCode.toString(),
        'folderPath': folderPath,
        'dateAdded': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
  }

  Future<int> removeMonitoredFolder(String folderPath) async {
    final db = await database;
    return await db.delete(
      'monitored_folders',
      where: 'folderPath = ?',
      whereArgs: [folderPath],
    );
  }
}
