class PlaylistModel {
  final String id;
  final String title;
  final String? description;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<String> mediaItemIds;

  const PlaylistModel({
    required this.id,
    required this.title,
    this.description,
    required this.createdAt,
    required this.updatedAt,
    this.mediaItemIds = const [],
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'createdAt': createdAt.millisecondsSinceEpoch,
      'updatedAt': updatedAt.millisecondsSinceEpoch,
      'mediaItemIds': mediaItemIds.join(','),
    };
  }

  factory PlaylistModel.fromMap(Map<String, dynamic> map) {
    final idsStr = map['mediaItemIds'] as String? ?? '';
    final ids = idsStr.isEmpty ? <String>[] : idsStr.split(',');
    return PlaylistModel(
      id: map['id'] as String,
      title: map['title'] as String,
      description: map['description'] as String?,
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdAt'] as int? ?? 0),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(map['updatedAt'] as int? ?? 0),
      mediaItemIds: ids,
    );
  }
}

class HistoryItemModel {
  final String id;
  final String mediaItemId;
  final String title;
  final String path;
  final int positionMs;
  final int durationMs;
  final DateTime playedAt;

  const HistoryItemModel({
    required this.id,
    required this.mediaItemId,
    required this.title,
    required this.path,
    required this.positionMs,
    required this.durationMs,
    required this.playedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'mediaItemId': mediaItemId,
      'title': title,
      'path': path,
      'positionMs': positionMs,
      'durationMs': durationMs,
      'playedAt': playedAt.millisecondsSinceEpoch,
    };
  }

  factory HistoryItemModel.fromMap(Map<String, dynamic> map) {
    return HistoryItemModel(
      id: map['id'] as String,
      mediaItemId: map['mediaItemId'] as String,
      title: map['title'] as String,
      path: map['path'] as String,
      positionMs: map['positionMs'] as int? ?? 0,
      durationMs: map['durationMs'] as int? ?? 0,
      playedAt: DateTime.fromMillisecondsSinceEpoch(map['playedAt'] as int? ?? 0),
    );
  }
}

class VaultItemModel {
  final String id;
  final String originalName;
  final String encryptedPath;
  final int fileSizeBytes;
  final int mediaTypeIndex;
  final DateTime dateEncrypted;

  const VaultItemModel({
    required this.id,
    required this.originalName,
    required this.encryptedPath,
    required this.fileSizeBytes,
    required this.mediaTypeIndex,
    required this.dateEncrypted,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'originalName': originalName,
      'encryptedPath': encryptedPath,
      'fileSizeBytes': fileSizeBytes,
      'mediaTypeIndex': mediaTypeIndex,
      'dateEncrypted': dateEncrypted.millisecondsSinceEpoch,
    };
  }

  factory VaultItemModel.fromMap(Map<String, dynamic> map) {
    return VaultItemModel(
      id: map['id'] as String,
      originalName: map['originalName'] as String,
      encryptedPath: map['encryptedPath'] as String,
      fileSizeBytes: map['fileSizeBytes'] as int? ?? 0,
      mediaTypeIndex: map['mediaTypeIndex'] as int? ?? 0,
      dateEncrypted: DateTime.fromMillisecondsSinceEpoch(map['dateEncrypted'] as int? ?? 0),
    );
  }
}

enum DownloadStatus { pending, downloading, paused, completed, failed, cancelled }

class DownloadTaskModel {
  final String id;
  final String url;
  final String destinationPath;
  final String fileName;
  final int totalBytes;
  final int downloadedBytes;
  final DownloadStatus status;
  final String? errorMessage;
  final DateTime createdAt;

  const DownloadTaskModel({
    required this.id,
    required this.url,
    required this.destinationPath,
    required this.fileName,
    this.totalBytes = 0,
    this.downloadedBytes = 0,
    this.status = DownloadStatus.pending,
    this.errorMessage,
    required this.createdAt,
  });

  double get progress => totalBytes > 0 ? (downloadedBytes / totalBytes).clamp(0.0, 1.0) : 0.0;
}
