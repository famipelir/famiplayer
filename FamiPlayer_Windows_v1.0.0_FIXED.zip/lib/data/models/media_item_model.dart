import '../../core/utils/media_type_detector.dart';

class MediaItemModel {
  final String id;
  final String path;
  final String title;
  final String? artist;
  final String? album;
  final String? genre;
  final MediaType mediaType;
  final int durationMs;
  final int fileSizeBytes;
  final int width;
  final int height;
  final int lastPlayedPositionMs;
  final DateTime dateAdded;
  final DateTime? lastPlayedAt;
  final bool isFavorite;
  final String? thumbnailPath;

  const MediaItemModel({
    required this.id,
    required this.path,
    required this.title,
    this.artist,
    this.album,
    this.genre,
    required this.mediaType,
    this.durationMs = 0,
    this.fileSizeBytes = 0,
    this.width = 0,
    this.height = 0,
    this.lastPlayedPositionMs = 0,
    required this.dateAdded,
    this.lastPlayedAt,
    this.isFavorite = false,
    this.thumbnailPath,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'path': path,
      'title': title,
      'artist': artist,
      'album': album,
      'genre': genre,
      'mediaType': mediaType.index,
      'durationMs': durationMs,
      'fileSizeBytes': fileSizeBytes,
      'width': width,
      'height': height,
      'lastPlayedPositionMs': lastPlayedPositionMs,
      'dateAdded': dateAdded.millisecondsSinceEpoch,
      'lastPlayedAt': lastPlayedAt?.millisecondsSinceEpoch,
      'isFavorite': isFavorite ? 1 : 0,
      'thumbnailPath': thumbnailPath,
    };
  }

  factory MediaItemModel.fromMap(Map<String, dynamic> map) {
    return MediaItemModel(
      id: map['id'] as String,
      path: map['path'] as String,
      title: map['title'] as String,
      artist: map['artist'] as String?,
      album: map['album'] as String?,
      genre: map['genre'] as String?,
      mediaType: MediaType.values[map['mediaType'] as int? ?? 0],
      durationMs: map['durationMs'] as int? ?? 0,
      fileSizeBytes: map['fileSizeBytes'] as int? ?? 0,
      width: map['width'] as int? ?? 0,
      height: map['height'] as int? ?? 0,
      lastPlayedPositionMs: map['lastPlayedPositionMs'] as int? ?? 0,
      dateAdded: DateTime.fromMillisecondsSinceEpoch(map['dateAdded'] as int? ?? 0),
      lastPlayedAt: map['lastPlayedAt'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['lastPlayedAt'] as int)
          : null,
      isFavorite: (map['isFavorite'] as int? ?? 0) == 1,
      thumbnailPath: map['thumbnailPath'] as String?,
    );
  }

  MediaItemModel copyWith({
    String? id,
    String? path,
    String? title,
    String? artist,
    String? album,
    String? genre,
    MediaType? mediaType,
    int? durationMs,
    int? fileSizeBytes,
    int? width,
    int? height,
    int? lastPlayedPositionMs,
    DateTime? dateAdded,
    DateTime? lastPlayedAt,
    bool? isFavorite,
    String? thumbnailPath,
  }) {
    return MediaItemModel(
      id: id ?? this.id,
      path: path ?? this.path,
      title: title ?? this.title,
      artist: artist ?? this.artist,
      album: album ?? this.album,
      genre: genre ?? this.genre,
      mediaType: mediaType ?? this.mediaType,
      durationMs: durationMs ?? this.durationMs,
      fileSizeBytes: fileSizeBytes ?? this.fileSizeBytes,
      width: width ?? this.width,
      height: height ?? this.height,
      lastPlayedPositionMs: lastPlayedPositionMs ?? this.lastPlayedPositionMs,
      dateAdded: dateAdded ?? this.dateAdded,
      lastPlayedAt: lastPlayedAt ?? this.lastPlayedAt,
      isFavorite: isFavorite ?? this.isFavorite,
      thumbnailPath: thumbnailPath ?? this.thumbnailPath,
    );
  }
}
