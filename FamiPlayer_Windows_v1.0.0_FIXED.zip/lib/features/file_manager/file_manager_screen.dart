import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/media_type_detector.dart';
import '../../data/database/app_database.dart';
import '../../data/models/media_item_model.dart';

class FileManagerScreen extends StatefulWidget {
  final ValueChanged<MediaItemModel> onPlayMedia;

  const FileManagerScreen({super.key, required this.onPlayMedia});

  @override
  State<FileManagerScreen> createState() => _FileManagerScreenState();
}

class _FileManagerScreenState extends State<FileManagerScreen> {
  Directory? _currentDirectory;
  List<FileSystemEntity> _entities = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _initDefaultDirectory();
  }

  Future<void> _initDefaultDirectory() async {
    final docs = await getApplicationDocumentsDirectory();
    await _loadDirectory(docs.parent);
  }

  Future<void> _loadDirectory(Directory dir) async {
    setState(() => _isLoading = true);
    try {
      final list = dir.listSync().where((e) {
        final name = p.basename(e.path);
        return !name.startsWith('.');
      }).toList();

      list.sort((a, b) {
        if (a is Directory && b is! Directory) return -1;
        if (a is! Directory && b is Directory) return 1;
        return a.path.toLowerCase().compareTo(b.path.toLowerCase());
      });

      setState(() {
        _currentDirectory = dir;
        _entities = list;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          _currentDirectory?.path ?? l10n.get('nav_file_manager'),
          style: const TextStyle(fontSize: 14),
        ),
        leading: _currentDirectory?.parent != null
            ? IconButton(
                icon: const Icon(Icons.arrow_upward_rounded),
                onPressed: () => _loadDirectory(_currentDirectory!.parent),
              )
            : null,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _entities.length,
              itemBuilder: (context, index) {
                final entity = _entities[index];
                final isDir = entity is Directory;
                final name = p.basename(entity.path);

                return ListTile(
                  leading: Icon(
                    isDir
                        ? Icons.folder_rounded
                        : MediaTypeDetector.isVideo(entity.path)
                            ? Icons.movie_outlined
                            : MediaTypeDetector.isAudio(entity.path)
                                ? Icons.music_note_rounded
                                : Icons.insert_drive_file_outlined,
                    color: isDir ? accentColor : AppColors.textSecondary,
                  ),
                  title: Text(name, style: const TextStyle(color: AppColors.textPrimary, fontSize: 13)),
                  onTap: () {
                    if (isDir) {
                      _loadDirectory(entity as Directory);
                    } else if (MediaTypeDetector.isPlayableMedia(entity.path)) {
                      final media = MediaItemModel(
                        id: entity.path.hashCode.toString(),
                        path: entity.path,
                        title: p.basenameWithoutExtension(entity.path),
                        mediaType: MediaTypeDetector.detectFromFilePath(entity.path),
                        dateAdded: DateTime.now(),
                      );
                      widget.onPlayMedia(media);
                    }
                  },
                );
              },
            ),
    );
  }
}
