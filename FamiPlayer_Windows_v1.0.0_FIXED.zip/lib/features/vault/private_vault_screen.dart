import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import '../../core/localization/app_localizations.dart';
import '../../core/security/vault_security_service.dart';
import '../../core/theme/app_colors.dart';
import '../../data/database/app_database.dart';
import '../../data/models/playlist_model.dart';
import '../../shared/widgets/empty_state.dart';

class PrivateVaultScreen extends StatefulWidget {
  const PrivateVaultScreen({super.key});

  @override
  State<PrivateVaultScreen> createState() => _PrivateVaultScreenState();
}

class _PrivateVaultScreenState extends State<PrivateVaultScreen> {
  final VaultSecurityService _securityService = VaultSecurityService();
  final TextEditingController _pinController = TextEditingController();

  bool _isConfigured = false;
  bool _isUnlocked = false;
  bool _isLoading = true;
  String? _errorMessage;
  List<VaultItemModel> _vaultItems = [];

  @override
  void initState() {
    super.initState();
    _checkVaultState();
  }

  Future<void> _checkVaultState() async {
    final configured = await _securityService.isVaultConfigured();
    if (mounted) {
      setState(() {
        _isConfigured = configured;
        _isLoading = false;
      });
    }
  }

  Future<void> _unlockOrSetup() async {
    final pin = _pinController.text.trim();
    if (pin.length < 4) {
      setState(() => _errorMessage = 'PIN must be at least 4 digits');
      return;
    }

    if (!_isConfigured) {
      // Set new PIN
      await _securityService.setPin(pin);
      final items = await AppDatabase.instance.getVaultItems();
      setState(() {
        _isConfigured = true;
        _isUnlocked = true;
        _vaultItems = items;
        _errorMessage = null;
      });
    } else {
      // Verify PIN
      final valid = await _securityService.verifyPin(pin);
      if (valid) {
        final items = await AppDatabase.instance.getVaultItems();
        setState(() {
          _isUnlocked = true;
          _vaultItems = items;
          _errorMessage = null;
        });
      } else {
        setState(() => _errorMessage = 'Incorrect PIN code');
      }
    }
  }

  Future<void> _importFileToVault() async {
    final result = await FilePicker.platform.pickFiles();
    if (result != null && result.files.single.path != null) {
      final source = File(result.files.single.path!);
      final pin = _pinController.text.trim();
      final originalName = result.files.single.name;

      final encrypted = await _securityService.encryptAndStoreFile(
        sourceFile: source,
        pin: pin,
        originalName: originalName,
      );

      final item = VaultItemModel(
        id: encrypted.path.hashCode.toString(),
        originalName: originalName,
        encryptedPath: encrypted.path,
        fileSizeBytes: await source.length(),
        mediaTypeIndex: 0,
        dateEncrypted: DateTime.now(),
      );

      await AppDatabase.instance.saveVaultItem(item);
      final updatedList = await AppDatabase.instance.getVaultItems();

      if (mounted) {
        setState(() {
          _vaultItems = updatedList;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$originalName encrypted and stored in Private Vault'),
            backgroundColor: AppColors.cyanPrimary,
          ),
        );
      }
    }
  }

  Future<void> _exportAndDecrypt(VaultItemModel item) async {
    final saveDir = await FilePicker.platform.getDirectoryPath();
    if (saveDir == null) return;

    try {
      final pin = _pinController.text.trim();
      final encryptedFile = File(item.encryptedPath);
      if (!await encryptedFile.exists()) {
        throw Exception('Encrypted file not found on disk.');
      }

      final decryptedBytes = await _securityService.decryptFile(
        encryptedFile: encryptedFile,
        pin: pin,
      );

      final destinationPath = p.join(saveDir, item.originalName);
      final destFile = File(destinationPath);
      await destFile.writeAsBytes(decryptedBytes, flush: true);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Decrypted and exported to $destinationPath'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to decrypt: $e'),
            backgroundColor: AppColors.error,
          ),
        );
      }
    }
  }

  Future<void> _deleteVaultItem(VaultItemModel item) async {
    final encryptedFile = File(item.encryptedPath);
    await _securityService.secureShredFile(encryptedFile);
    await AppDatabase.instance.deleteVaultItem(item.id);

    final updated = await AppDatabase.instance.getVaultItems();
    if (mounted) {
      setState(() => _vaultItems = updated);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;

    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (!_isUnlocked) {
      return Scaffold(
        body: Center(
          child: Container(
            constraints: const BoxConstraints(maxWidth: 420),
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: AppColors.surfaceCard,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: accentColor.withOpacity(0.15),
                    border: Border.all(color: accentColor.withOpacity(0.4)),
                  ),
                  child: Icon(Icons.lock_rounded, color: accentColor, size: 30),
                ),
                const SizedBox(height: 16),
                Text(
                  l10n.get('vault_title'),
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  l10n.get('vault_desc'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
                const SizedBox(height: 24),
                TextField(
                  controller: _pinController,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 22, letterSpacing: 8, color: Colors.white),
                  decoration: InputDecoration(
                    hintText: '••••',
                    hintStyle: const TextStyle(letterSpacing: 8, color: AppColors.textTertiary),
                    filled: true,
                    fillColor: AppColors.surfaceInput,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: AppColors.border),
                    ),
                  ),
                  onSubmitted: (_) => _unlockOrSetup(),
                ),
                if (_errorMessage != null) ...[
                  const SizedBox(height: 8),
                  Text(_errorMessage!, style: const TextStyle(color: AppColors.error, fontSize: 12)),
                ],
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 46,
                  child: ElevatedButton(
                    onPressed: _unlockOrSetup,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accentColor,
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    child: Text(
                      _isConfigured ? l10n.get('vault_unlock') : l10n.get('vault_set_pin'),
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.get('vault_title')),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_rounded),
            tooltip: l10n.get('vault_import_file'),
            onPressed: _importFileToVault,
          ),
          IconButton(
            icon: const Icon(Icons.lock_rounded),
            tooltip: l10n.get('vault_lock'),
            onPressed: () {
              setState(() {
                _isUnlocked = false;
                _pinController.clear();
              });
            },
          ),
        ],
      ),
      body: _vaultItems.isEmpty
          ? EmptyStateView(
              icon: Icons.shield_outlined,
              title: 'Vault is Empty',
              description: l10n.get('vault_empty'),
              actionLabel: l10n.get('vault_import_file'),
              onActionPressed: _importFileToVault,
            )
          : ListView.builder(
              padding: const EdgeInsets.all(20),
              itemCount: _vaultItems.length,
              itemBuilder: (context, index) {
                final item = _vaultItems[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceCard,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.border.withOpacity(0.5)),
                  ),
                  child: ListTile(
                    leading: const Icon(Icons.enhanced_encryption_rounded, color: AppColors.cyanPrimary),
                    title: Text(item.originalName, style: const TextStyle(color: AppColors.textPrimary)),
                    subtitle: Text(
                      'AES-256 GCM • ${(item.fileSizeBytes / (1024 * 1024)).toStringAsFixed(2)} MB',
                      style: const TextStyle(color: AppColors.textSecondary, fontSize: 11),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.file_download_rounded, color: AppColors.cyanPrimary),
                          tooltip: 'Export & Decrypt to Disk',
                          onPressed: () => _exportAndDecrypt(item),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_forever_rounded, color: AppColors.error),
                          tooltip: 'Secure Shred & Delete',
                          onPressed: () => _deleteVaultItem(item),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
