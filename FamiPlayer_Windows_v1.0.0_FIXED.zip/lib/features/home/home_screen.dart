import 'package:desktop_drop/desktop_drop.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/media_type_detector.dart';
import '../../data/database/app_database.dart';
import '../../data/models/media_item_model.dart';
import '../../services/library_scanner_service.dart';
import '../../services/media_engine_service.dart';
import '../../shared/widgets/empty_state.dart';
import '../../shared/widgets/media_card.dart';

class HomeScreen extends StatefulWidget {
  final VoidCallback onNavigateToUrl;
  final ValueChanged<MediaItemModel> onPlayMedia;

  const HomeScreen({
    super.key,
    required this.onNavigateToUrl,
    required this.onPlayMedia,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<MediaItemModel> _continueWatching = [];
  List<MediaItemModel> _recentlyAdded = [];
  List<MediaItemModel> _favorites = [];
  bool _isLoading = true;
  bool _isDragging = false;

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    setState(() => _isLoading = true);
    final allItems = await AppDatabase.instance.getAllMediaItems();
    final recentWatched = await AppDatabase.instance.getRecentlyPlayedItems(limit: 6);
    final favs = await AppDatabase.instance.getFavoriteItems();

    if (mounted) {
      setState(() {
        _continueWatching = recentWatched.where((m) => m.lastPlayedPositionMs > 2000).toList();
        _recentlyAdded = allItems.take(8).toList();
        _favorites = favs.take(6).toList();
        _isLoading = false;
      });
    }
  }

  Future<void> _pickAndOpenFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: [
        'mp4', 'mkv', 'webm', 'mov', 'avi', 'mp3', 'flac', 'wav', 'aac', 'jpg', 'png'
      ],
    );

    if (result != null && result.files.single.path != null) {
      final path = result.files.single.path!;
      final type = MediaTypeDetector.detectFromFilePath(path);
      final media = MediaItemModel(
        id: path.hashCode.toString(),
        path: path,
        title: result.files.single.name,
        mediaType: type,
        dateAdded: DateTime.now(),
      );
      await AppDatabase.instance.insertMediaItem(media);
      widget.onPlayMedia(media);
    }
  }

  Future<void> _scanFolderDialog() async {
    final selectedDirectory = await FilePicker.platform.getDirectoryPath();
    if (selectedDirectory != null) {
      final scanner = context.read<LibraryScannerService>();
      await scanner.scanFolder(selectedDirectory);
      await _loadDashboardData();
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;

    return DropTarget(
      onDragEntered: (_) => setState(() => _isDragging = true),
      onDragExited: (_) => setState(() => _isDragging = false),
      onDragDone: (details) async {
        setState(() => _isDragging = false);
        for (final file in details.files) {
          if (MediaTypeDetector.isPlayableMedia(file.path)) {
            final media = MediaItemModel(
              id: file.path.hashCode.toString(),
              path: file.path,
              title: file.name,
              mediaType: MediaTypeDetector.detectFromFilePath(file.path),
              dateAdded: DateTime.now(),
            );
            await AppDatabase.instance.insertMediaItem(media);
            widget.onPlayMedia(media);
            break;
          }
        }
      },
      child: Stack(
        children: [
          Scaffold(
            body: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _recentlyAdded.isEmpty
                    ? EmptyStateView(
                        icon: Icons.video_library_rounded,
                        title: l10n.get('home_no_media'),
                        description: 'Scan your local hard drive or drag media files here to start watching.',
                        actionLabel: l10n.get('home_scan_folder'),
                        onActionPressed: _scanFolderDialog,
                      )
                    : ListView(
                        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
                        children: [
                          // Quick Action Hub Header
                          _buildQuickActionsHeader(context, l10n, accentColor),
                          const SizedBox(height: 32),

                          // Continue Watching Section
                          if (_continueWatching.isNotEmpty) ...[
                            _buildSectionHeader(context, l10n.get('home_continue_watching')),
                            const SizedBox(height: 14),
                            _buildMediaGrid(_continueWatching),
                            const SizedBox(height: 32),
                          ],

                          // Recently Added Section
                          _buildSectionHeader(context, l10n.get('home_recently_added')),
                          const SizedBox(height: 14),
                          _buildMediaGrid(_recentlyAdded),
                          const SizedBox(height: 32),

                          // Favorites Section
                          if (_favorites.isNotEmpty) ...[
                            _buildSectionHeader(context, l10n.get('home_favorites')),
                            const SizedBox(height: 14),
                            _buildMediaGrid(_favorites),
                            const SizedBox(height: 32),
                          ],
                        ],
                      ),
          ),
          // Drag & Drop Visual Overlay
          if (_isDragging)
            Container(
              color: AppColors.obsidian.withOpacity(0.85),
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 36),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceCard,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: accentColor, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: accentColor.withOpacity(0.3),
                        blurRadius: 30,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.file_download_rounded, size: 54, color: accentColor),
                      const SizedBox(height: 16),
                      Text(
                        'Drop media file to play immediately',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildQuickActionsHeader(BuildContext context, AppLocalizations l10n, Color accentColor) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surfaceCard,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border.withOpacity(0.6)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'FAMI MEDIA COMMAND CENTER',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 2.0,
                    color: accentColor,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'High-Performance Windows Desktop Playback Engine',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          // Action Buttons
          OutlinedButton.icon(
            onPressed: _pickAndOpenFile,
            icon: const Icon(Icons.file_open_rounded, size: 18),
            label: Text(l10n.get('home_open_file')),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.textPrimary,
              side: const BorderSide(color: AppColors.border),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
          const SizedBox(width: 10),
          OutlinedButton.icon(
            onPressed: _scanFolderDialog,
            icon: const Icon(Icons.create_new_folder_rounded, size: 18),
            label: Text(l10n.get('home_scan_folder')),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.textPrimary,
              side: const BorderSide(color: AppColors.border),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
          const SizedBox(width: 10),
          ElevatedButton.icon(
            onPressed: widget.onNavigateToUrl,
            icon: const Icon(Icons.podcasts_rounded, size: 18, color: Colors.black),
            label: Text(l10n.get('home_play_stream')),
            style: ElevatedButton.styleFrom(
              backgroundColor: accentColor,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w700,
        color: AppColors.textPrimary,
      ),
    );
  }

  Widget _buildMediaGrid(List<MediaItemModel> items) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final int crossAxisCount = (constraints.maxWidth / 240).floor().clamp(2, 6);
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            crossAxisSpacing: 14,
            mainAxisSpacing: 14,
            childAspectRatio: 16 / 13,
          ),
          itemCount: items.length,
          itemBuilder: (context, index) {
            final item = items[index];
            return MediaCard(
              media: item,
              onTap: () => widget.onPlayMedia(item),
              onFavoriteToggle: () async {
                await AppDatabase.instance.toggleFavorite(item.id, !item.isFavorite);
                _loadDashboardData();
              },
            );
          },
        );
      },
    );
  }
}
