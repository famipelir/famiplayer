import 'package:flutter/material.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../data/database/app_database.dart';
import '../../data/models/media_item_model.dart';
import '../../shared/widgets/empty_state.dart';
import '../../shared/widgets/media_card.dart';

class GlobalSearchScreen extends StatefulWidget {
  final ValueChanged<MediaItemModel> onPlayMedia;

  const GlobalSearchScreen({super.key, required this.onPlayMedia});

  @override
  State<GlobalSearchScreen> createState() => _GlobalSearchScreenState();
}

class _GlobalSearchScreenState extends State<GlobalSearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<MediaItemModel> _allMedia = [];
  List<MediaItemModel> _results = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadAllMedia();
  }

  Future<void> _loadAllMedia() async {
    final items = await AppDatabase.instance.getAllMediaItems();
    if (mounted) {
      setState(() {
        _allMedia = items;
        _isLoading = false;
      });
    }
  }

  void _onSearchChanged(String query) {
    if (query.trim().isEmpty) {
      setState(() => _results = []);
      return;
    }

    final q = query.toLowerCase();
    setState(() {
      _results = _allMedia.where((m) {
        return m.title.toLowerCase().contains(q) ||
            (m.artist?.toLowerCase().contains(q) ?? false) ||
            (m.album?.toLowerCase().contains(q) ?? false) ||
            m.path.toLowerCase().contains(q);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;

    return Scaffold(
      body: Column(
        children: [
          // Search Input Bar
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            decoration: BoxDecoration(
              color: AppColors.surfaceCard,
              border: Border(bottom: BorderSide(color: AppColors.border.withOpacity(0.4))),
            ),
            child: TextField(
              controller: _searchController,
              autofocus: true,
              onChanged: _onSearchChanged,
              style: const TextStyle(fontSize: 15, color: Colors.white),
              decoration: InputDecoration(
                hintText: l10n.get('search_hint'),
                hintStyle: const TextStyle(color: AppColors.textTertiary),
                prefixIcon: const Icon(Icons.search_rounded, color: AppColors.textSecondary),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear_rounded, size: 18),
                        onPressed: () {
                          _searchController.clear();
                          _onSearchChanged('');
                        },
                      )
                    : null,
                filled: true,
                fillColor: AppColors.surfaceInput,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.border),
                ),
              ),
            ),
          ),
          // Results
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _searchController.text.trim().isEmpty
                    ? Center(
                        child: Text(
                          'Type above to search across your library...',
                          style: TextStyle(color: AppColors.textTertiary, fontSize: 14),
                        ),
                      )
                    : _results.isEmpty
                        ? EmptyStateView(
                            icon: Icons.search_off_rounded,
                            title: l10n.get('no_results'),
                            description: 'No matching videos, audio tracks, or photos found.',
                          )
                        : GridView.builder(
                            padding: const EdgeInsets.all(24),
                            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 4,
                              crossAxisSpacing: 14,
                              mainAxisSpacing: 14,
                              childAspectRatio: 16 / 13,
                            ),
                            itemCount: _results.length,
                            itemBuilder: (context, index) {
                              final item = _results[index];
                              return MediaCard(
                                media: item,
                                onTap: () => widget.onPlayMedia(item),
                              );
                            },
                          ),
          ),
        ],
      ),
    );
  }
}
