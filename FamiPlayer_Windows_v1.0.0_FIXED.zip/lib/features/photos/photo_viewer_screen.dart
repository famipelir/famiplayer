import 'dart:io';
import 'package:flutter/material.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/media_type_detector.dart';
import '../../data/database/app_database.dart';
import '../../data/models/media_item_model.dart';
import '../../shared/widgets/empty_state.dart';

class PhotoViewerScreen extends StatefulWidget {
  const PhotoViewerScreen({super.key});

  @override
  State<PhotoViewerScreen> createState() => _PhotoViewerScreenState();
}

class _PhotoViewerScreenState extends State<PhotoViewerScreen> {
  List<MediaItemModel> _photos = [];
  bool _isLoading = true;
  MediaItemModel? _activePhoto;
  double _rotationAngle = 0;

  @override
  void initState() {
    super.initState();
    _loadPhotos();
  }

  Future<void> _loadPhotos() async {
    setState(() => _isLoading = true);
    final items = await AppDatabase.instance.getMediaItemsByType(MediaType.photo.index);
    if (mounted) {
      setState(() {
        _photos = items;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;

    if (_activePhoto != null) {
      return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
            onPressed: () => setState(() => _activePhoto = null),
          ),
          title: Text(_activePhoto!.title, style: const TextStyle(color: Colors.white, fontSize: 16)),
          actions: [
            IconButton(
              icon: const Icon(Icons.rotate_right_rounded, color: Colors.white),
              tooltip: 'Rotate 90°',
              onPressed: () => setState(() => _rotationAngle += 1.5708),
            ),
            IconButton(
              icon: const Icon(Icons.fullscreen_rounded, color: Colors.white),
              onPressed: () {},
            ),
          ],
        ),
        body: Center(
          child: InteractiveViewer(
            panEnabled: true,
            minScale: 0.5,
            maxScale: 4.0,
            child: Transform.rotate(
              angle: _rotationAngle,
              child: Image.file(
                File(_activePhoto!.path),
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, size: 64, color: AppColors.error),
              ),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _photos.isEmpty
              ? EmptyStateView(
                  icon: Icons.photo_library_rounded,
                  title: 'No Photos Found',
                  description: 'Scan folders containing JPG, PNG, WEBP or BMP images.',
                )
              : GridView.builder(
                  padding: const EdgeInsets.all(24),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 5,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  itemCount: _photos.length,
                  itemBuilder: (context, index) {
                    final photo = _photos[index];
                    return InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => setState(() => _activePhoto = photo),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.border.withOpacity(0.5)),
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: Image.file(
                          File(photo.path),
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: AppColors.surfaceCard,
                            child: const Icon(Icons.broken_image, color: AppColors.textTertiary),
                          ),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
