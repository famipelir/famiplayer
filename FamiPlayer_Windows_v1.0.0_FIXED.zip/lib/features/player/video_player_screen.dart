import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:provider/provider.dart';
import 'package:window_manager/window_manager.dart';
import '../../core/constants/app_constants.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/media_item_model.dart';
import '../../services/media_engine_service.dart';
import 'widgets/equalizer_dialog.dart';
import 'widgets/resume_playback_dialog.dart';

class VideoPlayerScreen extends StatefulWidget {
  final MediaItemModel? initialMedia;
  final VoidCallback onBack;

  const VideoPlayerScreen({
    super.key,
    this.initialMedia,
    required this.onBack,
  });

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  bool _showControls = true;
  Timer? _hideTimer;
  bool _isFullscreen = false;
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _startHideTimer();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final engine = context.read<MediaEngineService>();
      if (widget.initialMedia != null) {
        if (widget.initialMedia!.lastPlayedPositionMs > 5000) {
          showDialog(
            context: context,
            builder: (ctx) => ResumePlaybackDialog(
              resumePositionMs: widget.initialMedia!.lastPlayedPositionMs,
              onResume: () => engine.openMedia(widget.initialMedia!, startFromBeginning: false),
              onStartFromBeginning: () => engine.openMedia(widget.initialMedia!, startFromBeginning: true),
            ),
          );
        } else {
          engine.openMedia(widget.initialMedia!);
        }
      }
    });
  }

  void _startHideTimer() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 4), () {
      if (mounted && context.read<MediaEngineService>().isPlaying) {
        setState(() => _showControls = false);
      }
    });
  }

  void _onUserActivity() {
    if (!_showControls) {
      setState(() => _showControls = true);
    }
    _startHideTimer();
  }

  Future<void> _toggleFullscreen() async {
    final isFull = await windowManager.isFullScreen();
    await windowManager.setFullScreen(!isFull);
    setState(() => _isFullscreen = !isFull);
  }

  Future<void> _captureScreenshot(MediaEngineService engine, AppLocalizations l10n) async {
    final path = await engine.takeScreenshot();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(path != null
              ? '${l10n.get('player_screenshot_saved')}: $path'
              : l10n.get('player_screenshot_saved')),
          backgroundColor: AppColors.cyanPrimary,
        ),
      );
    }
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final engine = context.watch<MediaEngineService>();
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;

    return Focus(
      focusNode: _focusNode,
      autofocus: true,
      onKey: (node, event) {
        if (event is RawKeyDownEvent) {
          if (event.logicalKey == LogicalKeyboardKey.space) {
            engine.playOrPause();
            _onUserActivity();
            return KeyEventResult.handled;
          } else if (event.logicalKey == LogicalKeyboardKey.arrowLeft) {
            engine.seekRelative(-5);
            _onUserActivity();
            return KeyEventResult.handled;
          } else if (event.logicalKey == LogicalKeyboardKey.arrowRight) {
            engine.seekRelative(5);
            _onUserActivity();
            return KeyEventResult.handled;
          } else if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
            engine.setVolume(engine.volume + 5);
            _onUserActivity();
            return KeyEventResult.handled;
          } else if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
            engine.setVolume(engine.volume - 5);
            _onUserActivity();
            return KeyEventResult.handled;
          } else if (event.logicalKey == LogicalKeyboardKey.keyF) {
            _toggleFullscreen();
            return KeyEventResult.handled;
          } else if (event.logicalKey == LogicalKeyboardKey.escape && _isFullscreen) {
            _toggleFullscreen();
            return KeyEventResult.handled;
          } else if (event.logicalKey == LogicalKeyboardKey.keyM) {
            engine.toggleMute();
            _onUserActivity();
            return KeyEventResult.handled;
          } else if (event.logicalKey == LogicalKeyboardKey.bracketLeft) {
            engine.stepFrameBackward();
            _onUserActivity();
            return KeyEventResult.handled;
          } else if (event.logicalKey == LogicalKeyboardKey.bracketRight) {
            engine.stepFrameForward();
            _onUserActivity();
            return KeyEventResult.handled;
          }
        }
        return KeyEventResult.ignored;
      },
      child: MouseRegion(
        onHover: (_) => _onUserActivity(),
        child: GestureDetector(
          onTap: () {
            _onUserActivity();
            engine.playOrPause();
          },
          onDoubleTap: _toggleFullscreen,
          child: Scaffold(
            backgroundColor: Colors.black,
            body: Stack(
              fit: StackFit.expand,
              children: [
                // Video Viewport
                Center(
                  child: Video(
                    controller: engine.videoController,
                    controls: NoVideoControls,
                    fit: _getVideoBoxFit(engine.aspectRatio),
                  ),
                ),

                // Controls Scrim Overlay
                if (_showControls) ...[
                  // Top Bar (Back button, Media title, Equalizer, Screenshot)
                  Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.black.withOpacity(0.85),
                            Colors.transparent,
                          ],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                      ),
                      child: Row(
                        children: [
                          IconButton(
                            icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                            onPressed: widget.onBack,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              engine.currentMedia?.title ?? 'Fami Player',
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          // Top Right Tools
                          IconButton(
                            icon: const Icon(Icons.equalizer_rounded, color: Colors.white),
                            tooltip: l10n.get('player_equalizer'),
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (_) => const EqualizerDialog(),
                              );
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.camera_alt_outlined, color: Colors.white),
                            tooltip: l10n.get('player_screenshot'),
                            onPressed: () => _captureScreenshot(engine, l10n),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Bottom Controls Hub
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.transparent,
                            Colors.black.withOpacity(0.92),
                          ],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Seek Bar
                          Row(
                            children: [
                              Text(
                                Formatters.formatDuration(engine.position),
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                              ),
                              Expanded(
                                child: Slider(
                                  value: engine.position.inMilliseconds.toDouble().clamp(
                                        0.0,
                                        engine.duration.inMilliseconds.toDouble() > 0
                                            ? engine.duration.inMilliseconds.toDouble()
                                            : 1.0,
                                      ),
                                  min: 0.0,
                                  max: engine.duration.inMilliseconds.toDouble() > 0
                                      ? engine.duration.inMilliseconds.toDouble()
                                      : 1.0,
                                  activeColor: accentColor,
                                  onChanged: (val) {
                                    engine.seek(Duration(milliseconds: val.toInt()));
                                    _onUserActivity();
                                  },
                                ),
                              ),
                              Text(
                                Formatters.formatDuration(engine.duration),
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),

                          // Control Buttons Row
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              // Left: Playback & Volume & Frame steps
                              Row(
                                children: [
                                  IconButton(
                                    icon: Icon(
                                      engine.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                                      color: accentColor,
                                      size: 32,
                                    ),
                                    onPressed: () {
                                      engine.playOrPause();
                                      _onUserActivity();
                                    },
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.skip_previous_rounded, color: Colors.white, size: 20),
                                    tooltip: '${l10n.get('player_frame_prev')} ([)',
                                    onPressed: () => engine.stepFrameBackward(),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.skip_next_rounded, color: Colors.white, size: 20),
                                    tooltip: '${l10n.get('player_frame_next')} (])',
                                    onPressed: () => engine.stepFrameForward(),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.replay_10_rounded, color: Colors.white),
                                    tooltip: 'Seek -10s',
                                    onPressed: () => engine.seekRelative(-10),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.forward_10_rounded, color: Colors.white),
                                    tooltip: 'Seek +10s',
                                    onPressed: () => engine.seekRelative(10),
                                  ),
                                  const SizedBox(width: 8),
                                  // Volume Slider
                                  IconButton(
                                    icon: Icon(
                                      engine.isMuted || engine.volume == 0
                                          ? Icons.volume_off_rounded
                                          : Icons.volume_up_rounded,
                                      color: Colors.white,
                                      size: 20,
                                    ),
                                    onPressed: () => engine.toggleMute(),
                                  ),
                                  SizedBox(
                                    width: 80,
                                    child: Slider(
                                      value: engine.isMuted ? 0 : engine.volume,
                                      min: 0.0,
                                      max: 100.0,
                                      activeColor: accentColor,
                                      onChanged: (val) => engine.setVolume(val),
                                    ),
                                  ),
                                ],
                              ),

                              // Center: A-B Loop Controls
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  if (engine.isAbLoopActive)
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                      margin: const EdgeInsets.only(right: 8),
                                      decoration: BoxDecoration(
                                        color: accentColor.withOpacity(0.2),
                                        borderRadius: BorderRadius.circular(6),
                                        border: Border.all(color: accentColor),
                                      ),
                                      child: Row(
                                        children: [
                                          Text(
                                            'A-B (${Formatters.formatDuration(engine.loopPointA!)} - ${Formatters.formatDuration(engine.loopPointB!)})',
                                            style: TextStyle(
                                              fontSize: 11,
                                              fontWeight: FontWeight.w700,
                                              color: accentColor,
                                            ),
                                          ),
                                          const SizedBox(width: 6),
                                          InkWell(
                                            onTap: () => engine.clearAbLoop(),
                                            child: const Icon(Icons.close, size: 14, color: Colors.white),
                                          ),
                                        ],
                                      ),
                                    )
                                  else
                                    PopupMenuButton<String>(
                                      tooltip: l10n.get('player_loop_ab'),
                                      icon: const Icon(Icons.repeat_rounded, color: Colors.white, size: 20),
                                      itemBuilder: (ctx) => [
                                        PopupMenuItem(
                                          value: 'set_a',
                                          child: Text('${l10n.get('player_set_a')} (${Formatters.formatDuration(engine.position)})'),
                                        ),
                                        PopupMenuItem(
                                          value: 'set_b',
                                          enabled: engine.loopPointA != null,
                                          child: Text('${l10n.get('player_set_b')} (${Formatters.formatDuration(engine.position)})'),
                                        ),
                                        if (engine.isAbLoopActive)
                                          PopupMenuItem(
                                            value: 'clear',
                                            child: Text(l10n.get('player_clear_loop')),
                                          ),
                                      ],
                                      onSelected: (action) {
                                        if (action == 'set_a') engine.setLoopPointA();
                                        if (action == 'set_b') engine.setLoopPointB();
                                        if (action == 'clear') engine.clearAbLoop();
                                      },
                                    ),
                                ],
                              ),

                              // Right: Speed, Aspect, Subtitles, Audio, Fullscreen
                              Row(
                                children: [
                                  // Speed Selector
                                  PopupMenuButton<double>(
                                    tooltip: l10n.get('player_speed'),
                                    initialValue: engine.rate,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: AppColors.surfaceCard,
                                        borderRadius: BorderRadius.circular(6),
                                      ),
                                      child: Text(
                                        '${engine.rate}x',
                                        style: const TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                    itemBuilder: (ctx) => AppConstants.playbackSpeeds.map((spd) {
                                      return PopupMenuItem(
                                        value: spd,
                                        child: Text('${spd}x'),
                                      );
                                    }).toList(),
                                    onSelected: (spd) => engine.setPlaybackSpeed(spd),
                                  ),
                                  const SizedBox(width: 8),

                                  // Aspect Ratio
                                  PopupMenuButton<VideoAspectRatio>(
                                    icon: const Icon(Icons.aspect_ratio_rounded, color: Colors.white),
                                    tooltip: l10n.get('player_aspect_ratio'),
                                    itemBuilder: (ctx) => [
                                      PopupMenuItem(
                                        value: VideoAspectRatio.fit,
                                        child: Text(l10n.get('player_fit_screen')),
                                      ),
                                      PopupMenuItem(
                                        value: VideoAspectRatio.stretch,
                                        child: Text(l10n.get('player_stretch')),
                                      ),
                                      PopupMenuItem(
                                        value: VideoAspectRatio.fill,
                                        child: Text(l10n.get('player_fill')),
                                      ),
                                      PopupMenuItem(
                                        value: VideoAspectRatio.original,
                                        child: Text(l10n.get('player_original')),
                                      ),
                                    ],
                                    onSelected: (ratio) => engine.setAspectRatio(ratio),
                                  ),

                                  // Subtitles Tracks Menu
                                  PopupMenuButton<SubtitleTrack>(
                                    icon: const Icon(Icons.subtitles_rounded, color: Colors.white),
                                    tooltip: l10n.get('player_subtitles'),
                                    itemBuilder: (ctx) {
                                      final items = <PopupMenuEntry<SubtitleTrack>>[
                                        PopupMenuItem(
                                          value: SubtitleTrack.no(),
                                          child: const Text('Off (No Subtitles)'),
                                        ),
                                        PopupMenuItem(
                                          value: SubtitleTrack.auto(),
                                          child: const Text('Auto Subtitles'),
                                        ),
                                      ];
                                      for (final sub in engine.subtitles) {
                                        items.add(
                                          PopupMenuItem(
                                            value: sub,
                                            child: Text(sub.title ?? sub.language ?? sub.id),
                                          ),
                                        );
                                      }
                                      return items;
                                    },
                                    onSelected: (track) => engine.setSubtitleTrack(track),
                                  ),

                                  // Audio Tracks Menu
                                  PopupMenuButton<AudioTrack>(
                                    icon: const Icon(Icons.audiotrack_rounded, color: Colors.white),
                                    tooltip: l10n.get('player_audio_tracks'),
                                    itemBuilder: (ctx) {
                                      final items = <PopupMenuEntry<AudioTrack>>[
                                        PopupMenuItem(
                                          value: AudioTrack.auto(),
                                          child: const Text('Auto Audio'),
                                        ),
                                      ];
                                      for (final aud in engine.audioTracks) {
                                        items.add(
                                          PopupMenuItem(
                                            value: aud,
                                            child: Text(aud.title ?? aud.language ?? aud.id),
                                          ),
                                        );
                                      }
                                      return items;
                                    },
                                    onSelected: (track) => engine.setAudioTrack(track),
                                  ),

                                  // Fullscreen
                                  IconButton(
                                    icon: Icon(
                                      _isFullscreen ? Icons.fullscreen_exit_rounded : Icons.fullscreen_rounded,
                                      color: Colors.white,
                                    ),
                                    tooltip: 'Fullscreen (F)',
                                    onPressed: _toggleFullscreen,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  BoxFit _getVideoBoxFit(VideoAspectRatio ratio) {
    switch (ratio) {
      case VideoAspectRatio.fit:
        return BoxFit.contain;
      case VideoAspectRatio.stretch:
        return BoxFit.fill;
      case VideoAspectRatio.fill:
        return BoxFit.cover;
      case VideoAspectRatio.original:
        return BoxFit.none;
    }
  }
}
