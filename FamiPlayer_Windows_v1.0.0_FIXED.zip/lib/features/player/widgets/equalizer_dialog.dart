import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/localization/app_localizations.dart';
import '../../../core/theme/app_colors.dart';
import '../../../services/equalizer_service.dart';

class EqualizerDialog extends StatelessWidget {
  const EqualizerDialog({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;
    final eq = context.watch<EqualizerService>();

    return Dialog(
      backgroundColor: AppColors.surfaceModal,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24),
        side: const BorderSide(color: AppColors.border),
      ),
      child: Container(
        width: 680,
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(Icons.equalizer_rounded, color: accentColor, size: 24),
                    const SizedBox(width: 12),
                    Text(
                      l10n.get('eq_title'),
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ],
                ),
                Switch(
                  value: eq.isEnabled,
                  activeColor: accentColor,
                  onChanged: (val) => eq.toggleEnabled(val),
                ),
              ],
            ),
            const SizedBox(height: 20),
            // Presets Selector
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: EqualizerPreset.values.map((preset) {
                final isSelected = eq.currentPreset == preset;
                return ChoiceChip(
                  label: Text(preset.displayName),
                  selected: isSelected,
                  selectedColor: accentColor.withOpacity(0.2),
                  backgroundColor: AppColors.surfaceCard,
                  side: BorderSide(
                    color: isSelected ? accentColor : AppColors.border,
                  ),
                  labelStyle: TextStyle(
                    fontSize: 12,
                    fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                    color: isSelected ? accentColor : AppColors.textSecondary,
                  ),
                  onSelected: (selected) {
                    if (selected) eq.applyPreset(preset);
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 28),
            // 10 Slider Bands
            Container(
              height: 220,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
              decoration: BoxDecoration(
                color: AppColors.surfaceCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border.withOpacity(0.5)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: List.generate(10, (index) {
                  final freq = AppConstants.equalizerFrequencies[index];
                  final freqLabel = freq >= 1000 ? '${freq ~/ 1000}k' : '$freq';
                  final gain = eq.bandGains[index];

                  return Column(
                    children: [
                      Text(
                        '${gain > 0 ? '+' : ''}${gain.toStringAsFixed(0)}',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: gain == 0 ? AppColors.textTertiary : accentColor,
                        ),
                      ),
                      Expanded(
                        child: RotatedBox(
                          quarterTurns: 3,
                          child: Slider(
                            value: gain,
                            min: -12.0,
                            max: 12.0,
                            activeColor: accentColor,
                            inactiveColor: AppColors.surfaceHighlight,
                            onChanged: eq.isEnabled
                                ? (val) => eq.setBandGain(index, val)
                                : null,
                          ),
                        ),
                      ),
                      Text(
                        freqLabel,
                        style: const TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  );
                }),
              ),
            ),
            const SizedBox(height: 24),
            // Footer
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () => eq.reset(),
                  child: Text(
                    l10n.get('eq_reset'),
                    style: const TextStyle(color: AppColors.textSecondary),
                  ),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.of(context).pop(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accentColor,
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: Text(
                    l10n.get('btn_close'),
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
