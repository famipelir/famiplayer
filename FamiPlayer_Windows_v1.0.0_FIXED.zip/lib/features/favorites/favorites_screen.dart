import 'package:flutter/material.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../data/database/app_database.dart';
import '../../data/models/media_item_model.dart';
import '../../shared/widgets/empty_state.dart';
import '../../shared/widgets/media_card.dart';

class FavoritesScreen extends StatefulWidget {
  final ValueChanged<MediaItemModel> onPlayMedia;

  const FavoritesScreen({super.key, required this.onPlayMedia});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  List<MediaItemModel> _favorites = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadFavorites();
  }

  Future<void> _loadFavorites() async {
    setState(() => _isLoading = true);
    final items = await AppDatabase.instance.getFavoriteItems();
    if (mounted) {
      setState(() {
        _favorites = items;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.get('nav_favorites')),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _favorites.isEmpty
              ? EmptyStateView(
                  icon: Icons.favorite_border_rounded,
                  title: 'No Favorites Yet',
                  description: 'Click the heart icon on any media item to add it to your favorites.',
                )
              : GridView.builder(
                  padding: const EdgeInsets.all(24),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    crossAxisSpacing: 14,
                    mainAxisSpacing: 14,
                    childAspectRatio: 16 / 13,
                  ),
                  itemCount: _favorites.length,
                  itemBuilder: (context, index) {
                    final item = _favorites[index];
                    return MediaCard(
                      media: item,
                      onTap: () => widget.onPlayMedia(item),
                      onFavoriteToggle: () async {
                        await AppDatabase.instance.toggleFavorite(item.id, false);
                        _loadFavorites();
                      },
                    );
                  },
                ),
    );
  }
}
