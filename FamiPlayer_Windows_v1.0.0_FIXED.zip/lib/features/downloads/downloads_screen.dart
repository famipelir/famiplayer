import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../data/models/playlist_model.dart';
import '../../services/download_manager_service.dart';
import '../../shared/widgets/empty_state.dart';

class DownloadsScreen extends StatefulWidget {
  const DownloadsScreen({super.key});

  @override
  State<DownloadsScreen> createState() => _DownloadsScreenState();
}

class _DownloadsScreenState extends State<DownloadsScreen> {
  final TextEditingController _urlController = TextEditingController();

  void _startNewDownload() {
    final url = _urlController.text.trim();
    if (url.isNotEmpty) {
      context.read<DownloadManagerService>().startDownload(url);
      _urlController.clear();
      Navigator.pop(context);
    }
  }

  void _showAddDownloadDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surfaceModal,
        title: const Text('Download Media from Direct URL', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: _urlController,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'https://example.com/video.mp4',
            hintStyle: TextStyle(color: AppColors.textTertiary),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: AppColors.textSecondary)),
          ),
          ElevatedButton(
            onPressed: _startNewDownload,
            child: const Text('Start Download'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;
    final downloadService = context.watch<DownloadManagerService>();

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.get('nav_downloads')),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_rounded),
            tooltip: 'Add Download URL',
            onPressed: _showAddDownloadDialog,
          ),
        ],
      ),
      body: downloadService.tasks.isEmpty
          ? EmptyStateView(
              icon: Icons.download_done_rounded,
              title: 'No Downloads in Progress',
              description: 'Download direct HTTP/HTTPS media streams directly to your local drive.',
              actionLabel: 'New Download',
              onActionPressed: _showAddDownloadDialog,
            )
          : ListView.builder(
              padding: const EdgeInsets.all(20),
              itemCount: downloadService.tasks.length,
              itemBuilder: (context, index) {
                final task = downloadService.tasks[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceCard,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.border.withOpacity(0.5)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            task.status == DownloadStatus.completed
                                ? Icons.check_circle_rounded
                                : task.status == DownloadStatus.failed
                                    ? Icons.error_rounded
                                    : Icons.downloading_rounded,
                            color: task.status == DownloadStatus.completed
                                ? AppColors.emeraldPrimary
                                : task.status == DownloadStatus.failed
                                    ? AppColors.error
                                    : accentColor,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              task.fileName,
                              style: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Text(
                            task.status.name.toUpperCase(),
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: task.status == DownloadStatus.completed
                                  ? AppColors.emeraldPrimary
                                  : task.status == DownloadStatus.failed
                                      ? AppColors.error
                                      : accentColor,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      LinearProgressIndicator(
                        value: task.progress,
                        backgroundColor: AppColors.surfaceHighlight,
                        valueColor: AlwaysStoppedAnimation(accentColor),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            '${Formatters.formatFileSize(task.downloadedBytes)} / ${Formatters.formatFileSize(task.totalBytes)}',
                            style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                          ),
                          Text(
                            '${(task.progress * 100).toStringAsFixed(1)}%',
                            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
