import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/media_type_detector.dart';
import '../../data/database/app_database.dart';
import '../../data/models/media_item_model.dart';
import '../../services/media_engine_service.dart';
import '../../shared/widgets/empty_state.dart';

class MusicLibraryScreen extends StatefulWidget {
  final ValueChanged<MediaItemModel> onPlayMusic;

  const MusicLibraryScreen({super.key, required this.onPlayMusic});

  @override
  State<MusicLibraryScreen> createState() => _MusicLibraryScreenState();
}

class _MusicLibraryScreenState extends State<MusicLibraryScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  List<MediaItemModel> _tracks = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadMusic();
  }

  Future<void> _loadMusic() async {
    setState(() => _isLoading = true);
    final items = await AppDatabase.instance.getMediaItemsByType(MediaType.audio.index);
    if (mounted) {
      setState(() {
        _tracks = items;
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;
    final engine = context.watch<MediaEngineService>();

    return Scaffold(
      body: Column(
        children: [
          // Music Sub-Navigation Tabs
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            color: AppColors.surfaceCard,
            child: Row(
              children: [
                TabBar(
                  controller: _tabController,
                  isScrollable: true,
                  indicatorColor: accentColor,
                  labelColor: accentColor,
                  unselectedLabelColor: AppColors.textSecondary,
                  tabs: const [
                    Tab(text: 'Songs'),
                    Tab(text: 'Artists'),
                    Tab(text: 'Albums'),
                    Tab(text: 'Folders'),
                  ],
                ),
                const Spacer(),
                OutlinedButton.icon(
                  onPressed: () {
                    if (_tracks.isNotEmpty) {
                      widget.onPlayMusic(_tracks.first);
                    }
                  },
                  icon: const Icon(Icons.shuffle_rounded, size: 16),
                  label: const Text('Shuffle All'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.textPrimary,
                    side: const BorderSide(color: AppColors.border),
                  ),
                ),
              ],
            ),
          ),
          // Content
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _tracks.isEmpty
                    ? EmptyStateView(
                        icon: Icons.music_note_rounded,
                        title: 'No Music Found',
                        description: 'Add your FLAC, MP3, AAC or WAV audio collections to Fami Player.',
                      )
                    : TabBarView(
                        controller: _tabController,
                        children: [
                          _buildSongsList(engine, accentColor),
                          _buildGroupedList('Artist', (m) => m.artist ?? 'Unknown Artist'),
                          _buildGroupedList('Album', (m) => m.album ?? 'Unknown Album'),
                          _buildGroupedList('Folder', (m) => m.path.split('/').reversed.skip(1).first),
                        ],
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildSongsList(MediaEngineService engine, Color accentColor) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _tracks.length,
      itemBuilder: (context, index) {
        final track = _tracks[index];
        final isPlayingThis = engine.currentMedia?.id == track.id;

        return Container(
          margin: const EdgeInsets.only(bottom: 6),
          decoration: BoxDecoration(
            color: isPlayingThis ? accentColor.withOpacity(0.12) : AppColors.surfaceCard,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: isPlayingThis ? accentColor.withOpacity(0.5) : AppColors.border.withOpacity(0.5),
            ),
          ),
          child: ListTile(
            leading: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: AppColors.surfaceHighlight,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                isPlayingThis && engine.isPlaying ? Icons.equalizer_rounded : Icons.music_note_rounded,
                color: isPlayingThis ? accentColor : AppColors.textSecondary,
                size: 20,
              ),
            ),
            title: Text(
              track.title,
              style: TextStyle(
                fontSize: 13.5,
                fontWeight: isPlayingThis ? FontWeight.w700 : FontWeight.w500,
                color: isPlayingThis ? accentColor : AppColors.textPrimary,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            subtitle: Text(
              track.artist ?? 'Unknown Artist',
              style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (track.durationMs > 0)
                  Text(
                    Formatters.formatDuration(Duration(milliseconds: track.durationMs)),
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                  ),
                const SizedBox(width: 12),
                IconButton(
                  icon: Icon(
                    track.isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    color: track.isFavorite ? AppColors.error : AppColors.textSecondary,
                    size: 18,
                  ),
                  onPressed: () async {
                    await AppDatabase.instance.toggleFavorite(track.id, !track.isFavorite);
                    _loadMusic();
                  },
                ),
              ],
            ),
            onTap: () => widget.onPlayMusic(track),
          ),
        );
      },
    );
  }

  Widget _buildGroupedList(String type, String Function(MediaItemModel) keySelector) {
    final Map<String, List<MediaItemModel>> groups = {};
    for (final t in _tracks) {
      final key = keySelector(t);
      groups.putIfAbsent(key, () => []).add(t);
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: groups.keys.length,
      itemBuilder: (context, index) {
        final groupName = groups.keys.elementAt(index);
        final count = groups[groupName]!.length;

        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          decoration: BoxDecoration(
            color: AppColors.surfaceCard,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.border.withOpacity(0.5)),
          ),
          child: ListTile(
            leading: const Icon(Icons.folder_special_rounded, color: AppColors.textSecondary),
            title: Text(groupName, style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w600)),
            subtitle: Text('$count tracks', style: const TextStyle(color: AppColors.textSecondary)),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () {
              widget.onPlayMusic(groups[groupName]!.first);
            },
          ),
        );
      },
    );
  }
}
