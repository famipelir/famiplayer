import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/media_type_detector.dart';

class PlayUrlScreen extends StatefulWidget {
  final ValueChanged<String> onPlayUrl;

  const PlayUrlScreen({super.key, required this.onPlayUrl});

  @override
  State<PlayUrlScreen> createState() => _PlayUrlScreenState();
}

class _PlayUrlScreenState extends State<PlayUrlScreen> {
  final TextEditingController _urlController = TextEditingController();
  bool _isValidating = false;
  String? _errorMessage;

  final List<String> _recentUrls = [
    'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
  ];

  Future<void> _validateAndPlay() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) return;

    setState(() {
      _isValidating = true;
      _errorMessage = null;
    });

    try {
      final uri = Uri.parse(url);
      if (!uri.isAbsolute) {
        throw Exception('Invalid URL format');
      }

      // Fast HEAD check
      final res = await http.head(uri).timeout(const Duration(seconds: 4));
      if (res.statusCode >= 400 && res.statusCode != 405) {
        throw Exception('HTTP Error ${res.statusCode}');
      }

      widget.onPlayUrl(url);
    } catch (e) {
      setState(() {
        _errorMessage = 'Unable to verify stream URL. Playing directly via Media Engine...';
      });
      // Allow fallback play even if head fails (e.g. CORS/stream servers)
      Future.delayed(const Duration(milliseconds: 600), () {
        widget.onPlayUrl(url);
      });
    } finally {
      setState(() => _isValidating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;

    return Scaffold(
      body: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 640),
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: accentColor.withOpacity(0.3)),
                    ),
                    child: Icon(Icons.podcasts_rounded, color: accentColor, size: 28),
                  ),
                  const SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        l10n.get('url_title'),
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Direct MP4, WebM, HLS (M3U8), and Live Streams',
                        style: const TextStyle(
                          fontSize: 13,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 28),

              // Input Box
              Container(
                decoration: BoxDecoration(
                  color: AppColors.surfaceInput,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.border),
                ),
                child: TextField(
                  controller: _urlController,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  decoration: InputDecoration(
                    hintText: l10n.get('url_hint'),
                    hintStyle: const TextStyle(color: AppColors.textTertiary),
                    prefixIcon: const Icon(Icons.link_rounded, color: AppColors.textSecondary),
                    suffixIcon: _urlController.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear, size: 18),
                            onPressed: () => setState(() => _urlController.clear()),
                          )
                        : null,
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  ),
                ),
              ),
              if (_errorMessage != null) ...[
                const SizedBox(height: 10),
                Text(
                  _errorMessage!,
                  style: const TextStyle(fontSize: 12, color: AppColors.warning),
                ),
              ],
              const SizedBox(height: 20),

              // Play Stream Button
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton.icon(
                  onPressed: _isValidating ? null : _validateAndPlay,
                  icon: _isValidating
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                        )
                      : const Icon(Icons.play_arrow_rounded, color: Colors.black, size: 24),
                  label: Text(
                    l10n.get('url_play_button'),
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: Colors.black,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accentColor,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    elevation: 6,
                    shadowColor: accentColor.withOpacity(0.4),
                  ),
                ),
              ),
              const SizedBox(height: 32),

              // Recent Samples
              Text(
                l10n.get('url_recent'),
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textSecondary,
                ),
              ),
              const SizedBox(height: 10),
              ..._recentUrls.map((sampleUrl) {
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceCard,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.border.withOpacity(0.5)),
                  ),
                  child: ListTile(
                    dense: true,
                    leading: Icon(
                      sampleUrl.endsWith('.m3u8') ? Icons.live_tv_rounded : Icons.movie_outlined,
                      color: accentColor,
                      size: 20,
                    ),
                    title: Text(
                      sampleUrl,
                      style: const TextStyle(fontSize: 12, color: AppColors.textPrimary),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: const Icon(Icons.play_circle_fill_rounded, size: 20),
                    onTap: () {
                      _urlController.text = sampleUrl;
                      _validateAndPlay();
                    },
                  ),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}
