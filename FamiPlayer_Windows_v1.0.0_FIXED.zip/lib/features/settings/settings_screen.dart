import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';
import '../../data/database/app_database.dart';
import '../../services/library_scanner_service.dart';

class SettingsScreen extends StatefulWidget {
  final ValueChanged<AppThemeMode> onThemeModeChanged;
  final ValueChanged<AppAccentColor> onAccentColorChanged;
  final ValueChanged<Locale> onLocaleChanged;
  final AppThemeMode currentThemeMode;
  final AppAccentColor currentAccentColor;
  final Locale currentLocale;

  const SettingsScreen({
    super.key,
    required this.onThemeModeChanged,
    required this.onAccentColorChanged,
    required this.onLocaleChanged,
    required this.currentThemeMode,
    required this.currentAccentColor,
    required this.currentLocale,
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  List<String> _monitoredFolders = [];
  bool _hwAccel = true;
  bool _rememberPosition = true;
  bool _autoPlayNext = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final folders = await AppDatabase.instance.getMonitoredFolders();
    if (mounted) {
      setState(() => _monitoredFolders = folders);
    }
  }

  Future<void> _addFolder() async {
    final selectedDirectory = await FilePicker.platform.getDirectoryPath();
    if (selectedDirectory != null) {
      await AppDatabase.instance.addMonitoredFolder(selectedDirectory);
      context.read<LibraryScannerService>().scanFolder(selectedDirectory);
      _loadSettings();
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;

    return Scaffold(
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
        children: [
          Text(
            l10n.get('nav_settings'),
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 24),

          // Appearance & Theme
          _buildCategoryHeader(l10n.get('settings_appearance')),
          _buildSettingsCard(
            children: [
              // Theme Mode
              ListTile(
                title: Text(l10n.get('settings_theme_mode'), style: const TextStyle(color: AppColors.textPrimary)),
                subtitle: const Text('Obsidian Dark, AMOLED Pure Black, Light', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                trailing: DropdownButton<AppThemeMode>(
                  value: widget.currentThemeMode,
                  dropdownColor: AppColors.surfaceModal,
                  items: [
                    DropdownMenuItem(
                      value: AppThemeMode.obsidian,
                      child: Text(l10n.get('settings_theme_dark')),
                    ),
                    DropdownMenuItem(
                      value: AppThemeMode.amoled,
                      child: Text(l10n.get('settings_theme_amoled')),
                    ),
                    DropdownMenuItem(
                      value: AppThemeMode.light,
                      child: Text(l10n.get('settings_theme_light')),
                    ),
                  ],
                  onChanged: (mode) {
                    if (mode != null) widget.onThemeModeChanged(mode);
                  },
                ),
              ),
              const Divider(color: AppColors.border, height: 1),

              // Accent Color
              ListTile(
                title: Text(l10n.get('settings_accent_color'), style: const TextStyle(color: AppColors.textPrimary)),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: AppAccentColor.values.map((accent) {
                    final color = AppTheme.getColor(accent);
                    final isSelected = widget.currentAccentColor == accent;
                    return InkWell(
                      onTap: () => widget.onAccentColorChanged(accent),
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: color,
                          border: isSelected ? Border.all(color: Colors.white, width: 2) : null,
                        ),
                        child: isSelected ? const Icon(Icons.check, size: 16, color: Colors.black) : null,
                      ),
                    );
                  }).toList(),
                ),
              ),
              const Divider(color: AppColors.border, height: 1),

              // Language Selector
              ListTile(
                title: Text(l10n.get('settings_language'), style: const TextStyle(color: AppColors.textPrimary)),
                trailing: DropdownButton<Locale>(
                  value: widget.currentLocale,
                  dropdownColor: AppColors.surfaceModal,
                  items: const [
                    DropdownMenuItem(
                      value: Locale('en'),
                      child: Text('English (US)'),
                    ),
                    DropdownMenuItem(
                      value: Locale('fa'),
                      child: Text('فارسی (Persian - RTL)'),
                    ),
                    DropdownMenuItem(
                      value: Locale('ar'),
                      child: Text('العربية (Arabic - RTL)'),
                    ),
                  ],
                  onChanged: (loc) {
                    if (loc != null) widget.onLocaleChanged(loc);
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 28),

          // Media Engine & Hardware
          _buildCategoryHeader(l10n.get('settings_playback')),
          _buildSettingsCard(
            children: [
              SwitchListTile(
                title: Text(l10n.get('settings_hw_accel'), style: const TextStyle(color: AppColors.textPrimary)),
                subtitle: const Text('GPU acceleration with D3D11 & DXVA2 for 4K/8K HDR decoding', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                value: _hwAccel,
                activeColor: accentColor,
                onChanged: (val) => setState(() => _hwAccel = val),
              ),
              const Divider(color: AppColors.border, height: 1),
              SwitchListTile(
                title: Text(l10n.get('settings_resume_playback'), style: const TextStyle(color: AppColors.textPrimary)),
                value: _rememberPosition,
                activeColor: accentColor,
                onChanged: (val) => setState(() => _rememberPosition = val),
              ),
              const Divider(color: AppColors.border, height: 1),
              SwitchListTile(
                title: Text(l10n.get('settings_auto_play_next'), style: const TextStyle(color: AppColors.textPrimary)),
                value: _autoPlayNext,
                activeColor: accentColor,
                onChanged: (val) => setState(() => _autoPlayNext = val),
              ),
            ],
          ),
          const SizedBox(height: 28),

          // Monitored Folders
          _buildCategoryHeader(l10n.get('settings_library')),
          _buildSettingsCard(
            children: [
              ListTile(
                title: Text(l10n.get('settings_library_folders'), style: const TextStyle(color: AppColors.textPrimary)),
                trailing: ElevatedButton.icon(
                  onPressed: _addFolder,
                  icon: const Icon(Icons.add, size: 16),
                  label: Text(l10n.get('settings_add_folder')),
                  style: ElevatedButton.styleFrom(backgroundColor: accentColor, foregroundColor: Colors.black),
                ),
              ),
              if (_monitoredFolders.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('No custom folders added. The default user media folders are scanned automatically.', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                )
              else
                ..._monitoredFolders.map((path) {
                  return ListTile(
                    dense: true,
                    leading: const Icon(Icons.folder_rounded, color: AppColors.textSecondary),
                    title: Text(path, style: const TextStyle(color: AppColors.textPrimary, fontSize: 12)),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline_rounded, color: AppColors.error, size: 18),
                      onPressed: () async {
                        await AppDatabase.instance.removeMonitoredFolder(path);
                        _loadSettings();
                      },
                    ),
                  );
                }),
            ],
          ),
          const SizedBox(height: 28),

          // About & Diagnostic
          _buildCategoryHeader(l10n.get('settings_about')),
          _buildSettingsCard(
            children: [
              ListTile(
                leading: const Icon(Icons.info_outline_rounded, color: AppColors.cyanPrimary),
                title: const Text('Fami Player for Windows', style: TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w600)),
                subtitle: const Text('Version 1.0.0 (Release x64) • Native Windows Engine', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, left: 4),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w700,
          color: AppColors.textSecondary,
        ),
      ),
    );
  }

  Widget _buildSettingsCard({required List<Widget> children}) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border.withOpacity(0.6)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: children,
      ),
    );
  }
}
