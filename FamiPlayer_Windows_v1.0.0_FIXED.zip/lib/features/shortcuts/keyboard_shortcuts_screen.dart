import 'package:flutter/material.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';

class KeyboardShortcutsScreen extends StatelessWidget {
  const KeyboardShortcutsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;

    const shortcuts = [
      {'key': 'Space', 'action': 'Play / Pause'},
      {'key': 'Left Arrow', 'action': 'Seek Backward 5 seconds'},
      {'key': 'Right Arrow', 'action': 'Seek Forward 5 seconds'},
      {'key': 'Up Arrow', 'action': 'Volume Up (+5%)'},
      {'key': 'Down Arrow', 'action': 'Volume Down (-5%)'},
      {'key': 'F', 'action': 'Toggle Fullscreen Mode'},
      {'key': 'M', 'action': 'Mute / Unmute Audio'},
      {'key': 'Escape', 'action': 'Exit Fullscreen Mode'},
      {'key': 'Ctrl + O', 'action': 'Open Local Media File'},
      {'key': 'Ctrl + L', 'action': 'Open Network Stream URL'},
      {'key': 'Ctrl + F', 'action': 'Focus Global Search'},
      {'key': '[ / ]', 'action': 'Decrease / Increase Playback Speed'},
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.get('nav_shortcuts')),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(24),
        itemCount: shortcuts.length,
        itemBuilder: (context, index) {
          final sc = shortcuts[index];
          return Container(
            margin: const EdgeInsets.only(bottom: 8),
            decoration: BoxDecoration(
              color: AppColors.surfaceCard,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.border.withOpacity(0.5)),
            ),
            child: ListTile(
              title: Text(sc['action']!, style: const TextStyle(color: AppColors.textPrimary, fontSize: 13.5)),
              trailing: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.surfaceHighlight,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: AppColors.border),
                ),
                child: Text(
                  sc['key']!,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: accentColor,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
