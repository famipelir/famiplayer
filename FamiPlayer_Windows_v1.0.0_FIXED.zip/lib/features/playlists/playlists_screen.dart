import 'package:flutter/material.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../data/database/app_database.dart';
import '../../data/models/playlist_model.dart';
import '../../shared/widgets/empty_state.dart';

class PlaylistsScreen extends StatefulWidget {
  const PlaylistsScreen({super.key});

  @override
  State<PlaylistsScreen> createState() => _PlaylistsScreenState();
}

class _PlaylistsScreenState extends State<PlaylistsScreen> {
  List<PlaylistModel> _playlists = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadPlaylists();
  }

  Future<void> _loadPlaylists() async {
    setState(() => _isLoading = true);
    final items = await AppDatabase.instance.getPlaylists();
    if (mounted) {
      setState(() {
        _playlists = items;
        _isLoading = false;
      });
    }
  }

  Future<void> _createPlaylistDialog() async {
    final titleController = TextEditingController();
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surfaceModal,
        title: const Text('Create Playlist', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: titleController,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'Playlist Name',
            hintStyle: TextStyle(color: AppColors.textTertiary),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: AppColors.textSecondary)),
          ),
          ElevatedButton(
            onPressed: () async {
              if (titleController.text.trim().isNotEmpty) {
                final playlist = PlaylistModel(
                  id: DateTime.now().millisecondsSinceEpoch.toString(),
                  title: titleController.text.trim(),
                  createdAt: DateTime.now(),
                  updatedAt: DateTime.now(),
                );
                await AppDatabase.instance.savePlaylist(playlist);
                Navigator.pop(ctx);
                _loadPlaylists();
              }
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.get('nav_playlists')),
        actions: [
          IconButton(
            icon: const Icon(Icons.playlist_add_rounded),
            tooltip: 'Create Playlist',
            onPressed: _createPlaylistDialog,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _playlists.isEmpty
              ? EmptyStateView(
                  icon: Icons.playlist_play_rounded,
                  title: 'No Playlists Created',
                  description: 'Create custom playlists to organize your favorite songs and videos.',
                  actionLabel: 'Create Playlist',
                  onActionPressed: _createPlaylistDialog,
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(20),
                  itemCount: _playlists.length,
                  itemBuilder: (context, index) {
                    final pl = _playlists[index];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: AppColors.surfaceCard,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppColors.border.withOpacity(0.5)),
                      ),
                      child: ListTile(
                        leading: Icon(Icons.playlist_play_rounded, color: accentColor, size: 28),
                        title: Text(pl.title, style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w600)),
                        subtitle: Text('${pl.mediaItemIds.length} items', style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline_rounded, color: AppColors.error, size: 18),
                          onPressed: () async {
                            await AppDatabase.instance.deletePlaylist(pl.id);
                            _loadPlaylists();
                          },
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
