import 'package:flutter/material.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/media_type_detector.dart';
import '../../data/database/app_database.dart';
import '../../data/models/media_item_model.dart';
import '../../shared/widgets/empty_state.dart';
import '../../shared/widgets/media_card.dart';

class VideoLibraryScreen extends StatefulWidget {
  final ValueChanged<MediaItemModel> onPlayVideo;

  const VideoLibraryScreen({super.key, required this.onPlayVideo});

  @override
  State<VideoLibraryScreen> createState() => _VideoLibraryScreenState();
}

class _VideoLibraryScreenState extends State<VideoLibraryScreen> {
  List<MediaItemModel> _videos = [];
  bool _isLoading = true;
  String _searchQuery = '';
  bool _isGridView = true;

  @override
  void initState() {
    super.initState();
    _loadVideos();
  }

  Future<void> _loadVideos() async {
    setState(() => _isLoading = true);
    final items = await AppDatabase.instance.getMediaItemsByType(MediaType.video.index);
    if (mounted) {
      setState(() {
        _videos = items;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;

    final filteredVideos = _videos.where((v) {
      if (_searchQuery.isEmpty) return true;
      return v.title.toLowerCase().contains(_searchQuery.toLowerCase());
    }).toList();

    return Scaffold(
      body: Column(
        children: [
          // Filter & View Toggle Bar
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
            decoration: BoxDecoration(
              color: AppColors.surfaceCard,
              border: Border(bottom: BorderSide(color: AppColors.border.withOpacity(0.4))),
            ),
            child: Row(
              children: [
                Text(
                  '${l10n.get('nav_videos')} (${filteredVideos.length})',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const Spacer(),
                // Search Field
                SizedBox(
                  width: 240,
                  height: 36,
                  child: TextField(
                    onChanged: (val) => setState(() => _searchQuery = val),
                    style: const TextStyle(fontSize: 13, color: Colors.white),
                    decoration: InputDecoration(
                      hintText: l10n.get('search_hint'),
                      hintStyle: const TextStyle(fontSize: 12, color: AppColors.textTertiary),
                      prefixIcon: const Icon(Icons.search, size: 18, color: AppColors.textSecondary),
                      contentPadding: EdgeInsets.zero,
                      filled: true,
                      fillColor: AppColors.surfaceInput,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: AppColors.border),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                // Grid/List toggle
                IconButton(
                  icon: Icon(
                    _isGridView ? Icons.view_list_rounded : Icons.grid_view_rounded,
                    color: AppColors.textSecondary,
                    size: 20,
                  ),
                  onPressed: () => setState(() => _isGridView = !_isGridView),
                ),
              ],
            ),
          ),
          // Videos Content
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : filteredVideos.isEmpty
                    ? EmptyStateView(
                        icon: Icons.movie_filter_rounded,
                        title: 'No Videos Found',
                        description: 'Scan media folders or drop MP4/MKV files into the application.',
                      )
                    : LayoutBuilder(
                        builder: (context, constraints) {
                          final int crossAxisCount =
                              (constraints.maxWidth / 240).floor().clamp(2, 6);
                          return GridView.builder(
                            padding: const EdgeInsets.all(24),
                            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: _isGridView ? crossAxisCount : 1,
                              crossAxisSpacing: 14,
                              mainAxisSpacing: 14,
                              childAspectRatio: _isGridView ? (16 / 13) : 6.0,
                            ),
                            itemCount: filteredVideos.length,
                            itemBuilder: (context, index) {
                              final item = filteredVideos[index];
                              return MediaCard(
                                media: item,
                                onTap: () => widget.onPlayVideo(item),
                                onFavoriteToggle: () async {
                                  await AppDatabase.instance.toggleFavorite(item.id, !item.isFavorite);
                                  _loadVideos();
                                },
                              );
                            },
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
