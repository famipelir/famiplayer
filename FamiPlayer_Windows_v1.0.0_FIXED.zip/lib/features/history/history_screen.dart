import 'package:flutter/material.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../data/database/app_database.dart';
import '../../data/models/media_item_model.dart';
import '../../shared/widgets/empty_state.dart';
import '../../shared/widgets/media_card.dart';

class HistoryScreen extends StatefulWidget {
  final ValueChanged<MediaItemModel> onPlayMedia;

  const HistoryScreen({super.key, required this.onPlayMedia});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<MediaItemModel> _history = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    setState(() => _isLoading = true);
    final items = await AppDatabase.instance.getRecentlyPlayedItems(limit: 50);
    if (mounted) {
      setState(() {
        _history = items;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.get('nav_history')),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _history.isEmpty
              ? EmptyStateView(
                  icon: Icons.history_rounded,
                  title: 'History is Empty',
                  description: 'Media you play will automatically appear here with saved timestamps.',
                )
              : GridView.builder(
                  padding: const EdgeInsets.all(24),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    crossAxisSpacing: 14,
                    mainAxisSpacing: 14,
                    childAspectRatio: 16 / 13,
                  ),
                  itemCount: _history.length,
                  itemBuilder: (context, index) {
                    final item = _history[index];
                    return MediaCard(
                      media: item,
                      onTap: () => widget.onPlayMedia(item),
                    );
                  },
                ),
    );
  }
}
