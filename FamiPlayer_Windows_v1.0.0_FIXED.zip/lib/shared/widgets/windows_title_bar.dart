import 'package:flutter/material.dart';
import 'package:window_manager/window_manager.dart';
import '../../core/theme/app_colors.dart';
import 'fami_logo.dart';

class WindowsTitleBar extends StatelessWidget {
  final Widget? leading;
  final Widget? title;
  final bool isFullScreen;

  const WindowsTitleBar({
    super.key,
    this.leading,
    this.title,
    this.isFullScreen = false,
  });

  @override
  Widget build(BuildContext context) {
    if (isFullScreen) return const SizedBox.shrink();

    return Container(
      height: 38,
      decoration: BoxDecoration(
        color: AppColors.obsidian,
        border: Border(
          bottom: BorderSide(
            color: AppColors.border.withOpacity(0.4),
            width: 1.0,
          ),
        ),
      ),
      child: Row(
        children: [
          const SizedBox(width: 12),
          const FamiLogo(size: 20, showTagline: false),
          const SizedBox(width: 16),
          if (leading != null) leading!,
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.translucent,
              onPanStart: (details) {
                windowManager.startDragging();
              },
              onDoubleTap: () async {
                if (await windowManager.isMaximized()) {
                  windowManager.unmaximize();
                } else {
                  windowManager.maximize();
                }
              },
              child: Container(
                alignment: Alignment.centerLeft,
                child: title ?? const SizedBox.shrink(),
              ),
            ),
          ),
          // Windows Window Controls (Minimize, Maximize, Close)
          _WindowButton(
            icon: Icons.remove,
            onPressed: () => windowManager.minimize(),
          ),
          _WindowButton(
            icon: Icons.crop_square,
            onPressed: () async {
              if (await windowManager.isMaximized()) {
                windowManager.unmaximize();
              } else {
                windowManager.maximize();
              }
            },
          ),
          _WindowButton(
            icon: Icons.close,
            isClose: true,
            onPressed: () => windowManager.close(),
          ),
        ],
      ),
    );
  }
}

class _WindowButton extends StatefulWidget {
  final IconData icon;
  final VoidCallback onPressed;
  final bool isClose;

  const _WindowButton({
    required this.icon,
    required this.onPressed,
    this.isClose = false,
  });

  @override
  State<_WindowButton> createState() => _WindowButtonState();
}

class _WindowButtonState extends State<_WindowButton> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    Color hoverColor = widget.isClose ? const Color(0xFFE81123) : AppColors.surfaceHighlight;

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: InkWell(
        onTap: widget.onPressed,
        child: Container(
          width: 46,
          height: 38,
          color: _isHovered ? hoverColor : Colors.transparent,
          child: Icon(
            widget.icon,
            size: 14,
            color: _isHovered && widget.isClose ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}
