import 'package:flutter/material.dart';
import '../../core/localization/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import 'fami_logo.dart';

enum NavDestination {
  home,
  videos,
  music,
  photos,
  playlists,
  favorites,
  history,
  downloads,
  playUrl,
  vault,
  fileManager,
  settings,
}

class FamiSidebar extends StatelessWidget {
  final NavDestination currentDestination;
  final ValueChanged<NavDestination> onDestinationSelected;
  final bool isCollapsed;
  final VoidCallback onToggleCollapse;

  const FamiSidebar({
    super.key,
    required this.currentDestination,
    required this.onDestinationSelected,
    required this.isCollapsed,
    required this.onToggleCollapse,
  });

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final accentColor = Theme.of(context).colorScheme.primary;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: isCollapsed ? 68 : 230,
      decoration: BoxDecoration(
        color: AppColors.surfaceNav,
        border: Border(
          right: BorderSide(
            color: AppColors.border.withOpacity(0.4),
            width: 1.0,
          ),
        ),
      ),
      child: Column(
        children: [
          // Logo & Collapse Button
          Container(
            height: 64,
            padding: const EdgeInsets.symmetric(horizontal: 14),
            alignment: Alignment.centerLeft,
            child: Row(
              mainAxisAlignment: isCollapsed ? MainAxisAlignment.center : MainAxisAlignment.spaceBetween,
              children: [
                if (!isCollapsed) const FamiLogo(size: 26),
                IconButton(
                  icon: Icon(
                    isCollapsed ? Icons.menu_open_rounded : Icons.menu_rounded,
                    color: AppColors.textSecondary,
                    size: 20,
                  ),
                  onPressed: onToggleCollapse,
                  tooltip: 'Toggle Sidebar',
                ),
              ],
            ),
          ),
          const Divider(color: AppColors.border, height: 1),
          // Nav Items Scroll List
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
              children: [
                _buildNavItem(
                  context,
                  destination: NavDestination.home,
                  icon: Icons.home_rounded,
                  label: l10n.get('nav_home'),
                ),
                _buildNavItem(
                  context,
                  destination: NavDestination.videos,
                  icon: Icons.movie_outlined,
                  activeIcon: Icons.movie_rounded,
                  label: l10n.get('nav_videos'),
                ),
                _buildNavItem(
                  context,
                  destination: NavDestination.music,
                  icon: Icons.music_note_outlined,
                  activeIcon: Icons.music_note_rounded,
                  label: l10n.get('nav_music'),
                ),
                _buildNavItem(
                  context,
                  destination: NavDestination.photos,
                  icon: Icons.photo_library_outlined,
                  activeIcon: Icons.photo_library_rounded,
                  label: l10n.get('nav_photos'),
                ),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  child: !isCollapsed
                      ? Text(
                          'LIBRARY',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.5,
                            color: AppColors.textTertiary,
                          ),
                        )
                      : const Divider(color: AppColors.border, height: 1),
                ),
                _buildNavItem(
                  context,
                  destination: NavDestination.playlists,
                  icon: Icons.playlist_play_rounded,
                  label: l10n.get('nav_playlists'),
                ),
                _buildNavItem(
                  context,
                  destination: NavDestination.favorites,
                  icon: Icons.favorite_border_rounded,
                  activeIcon: Icons.favorite_rounded,
                  label: l10n.get('nav_favorites'),
                ),
                _buildNavItem(
                  context,
                  destination: NavDestination.history,
                  icon: Icons.history_rounded,
                  label: l10n.get('nav_history'),
                ),
                _buildNavItem(
                  context,
                  destination: NavDestination.downloads,
                  icon: Icons.download_rounded,
                  label: l10n.get('nav_downloads'),
                ),
                _buildNavItem(
                  context,
                  destination: NavDestination.fileManager,
                  icon: Icons.folder_open_rounded,
                  label: l10n.get('nav_file_manager'),
                ),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  child: !isCollapsed
                      ? Text(
                          'TOOLS & SECURITY',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.5,
                            color: AppColors.textTertiary,
                          ),
                        )
                      : const Divider(color: AppColors.border, height: 1),
                ),
                _buildNavItem(
                  context,
                  destination: NavDestination.playUrl,
                  icon: Icons.podcasts_rounded,
                  label: l10n.get('nav_play_url'),
                ),
                _buildNavItem(
                  context,
                  destination: NavDestination.vault,
                  icon: Icons.lock_outline_rounded,
                  activeIcon: Icons.lock_rounded,
                  label: l10n.get('nav_vault'),
                ),
              ],
            ),
          ),
          const Divider(color: AppColors.border, height: 1),
          // Settings Item
          Padding(
            padding: const EdgeInsets.all(8),
            child: _buildNavItem(
              context,
              destination: NavDestination.settings,
              icon: Icons.settings_outlined,
              activeIcon: Icons.settings_rounded,
              label: l10n.get('nav_settings'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavItem(
    BuildContext context, {
    required NavDestination destination,
    required IconData icon,
    IconData? activeIcon,
    required String label,
  }) {
    final bool isSelected = currentDestination == destination;
    final accentColor = Theme.of(context).colorScheme.primary;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Tooltip(
        message: isCollapsed ? label : '',
        waitDuration: const Duration(milliseconds: 400),
        child: Material(
          color: isSelected ? accentColor.withOpacity(0.12) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          child: InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: () => onDestinationSelected(destination),
            hoverColor: AppColors.surfaceHighlight.withOpacity(0.5),
            child: Container(
              height: 42,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: isSelected
                    ? Border.all(color: accentColor.withOpacity(0.4), width: 1.0)
                    : null,
              ),
              child: Row(
                mainAxisAlignment: isCollapsed ? MainAxisAlignment.center : MainAxisAlignment.start,
                children: [
                  Icon(
                    isSelected ? (activeIcon ?? icon) : icon,
                    size: 20,
                    color: isSelected ? accentColor : AppColors.textSecondary,
                  ),
                  if (!isCollapsed) ...[
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        label,
                        style: TextStyle(
                          fontSize: 13.5,
                          fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                          color: isSelected ? Colors.white : AppColors.textSecondary,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
