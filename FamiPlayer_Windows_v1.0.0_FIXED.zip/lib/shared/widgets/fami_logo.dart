import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';

class FamiLogo extends StatelessWidget {
  final double size;
  final bool showTagline;

  const FamiLogo({
    super.key,
    this.size = 32.0,
    this.showTagline = true,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Custom Fami Icon (Cyber Squircle)
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(size * 0.28),
            gradient: const LinearGradient(
              colors: [Color(0xFF0F1B2E), Color(0xFF070B14)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(
              color: AppColors.cyanPrimary.withOpacity(0.6),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.cyanPrimary.withOpacity(0.25),
                blurRadius: 10,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Center(
            child: Icon(
              Icons.play_arrow_rounded,
              color: AppColors.cyanPrimary,
              size: size * 0.7,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            RichText(
              text: TextSpan(
                children: [
                  const TextSpan(
                    text: 'Fami',
                    style: TextStyle(
                      fontFamily: 'Segoe UI',
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 0.5,
                    ),
                  ),
                  TextSpan(
                    text: 'Player',
                    style: TextStyle(
                      fontFamily: 'Segoe UI',
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: Theme.of(context).colorScheme.primary,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
            if (showTagline)
              Text(
                'MEDIA ENGINE',
                style: TextStyle(
                  fontFamily: 'Segoe UI',
                  fontSize: 8.5,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 2.0,
                  color: AppColors.textSecondary.withOpacity(0.8),
                ),
              ),
          ],
        ),
      ],
    );
  }
}
