import 'package:flutter/material.dart';

class AppColors {
  // Brand Accents
  static const Color cyanPrimary = Color(0xFF00F0FF);
  static const Color cyanSecondary = Color(0xFF00B4D8);
  static const Color cyanTertiary = Color(0xFF0077B6);
  static const Color cyanGlow = Color(0x3300F0FF);

  static const Color amberPrimary = Color(0xFFFFB703);
  static const Color amberSecondary = Color(0xFFFB8500);
  static const Color amberGlow = Color(0x33FFB703);

  static const Color emeraldPrimary = Color(0xFF10B981);
  static const Color emeraldSecondary = Color(0xFF059669);
  static const Color emeraldGlow = Color(0x3310B981);

  static const Color violetPrimary = Color(0xFFA855F7);
  static const Color violetSecondary = Color(0xFF9333EA);
  static const Color violetGlow = Color(0x33A855F7);

  // Dark Surfaces (Fami Obsidian System)
  static const Color obsidian = Color(0xFF07090E);
  static const Color surface = Color(0xFF0F141F);
  static const Color surfaceCard = Color(0xFF0F1626);
  static const Color surfaceElevated = Color(0xFF161E2E);
  static const Color surfaceHighlight = Color(0xFF1F293D);
  static const Color surfaceInput = Color(0xFF131D31);
  static const Color surfaceModal = Color(0xFF0C1322);
  static const Color surfaceNav = Color(0xF00D121D);

  // AMOLED True-Black
  static const Color amoledBackground = Color(0xFF000000);
  static const Color amoledSurface = Color(0xFF080808);

  // Light Theme Surfaces
  static const Color lightBackground = Color(0xFFF1F5F9);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightSurfaceCard = Color(0xFFF8FAFC);
  static const Color lightBorder = Color(0xFFCBD5E1);

  // Typography
  static const Color textPrimary = Color(0xFFF8FAFC);
  static const Color textSecondary = Color(0xFF94A3B8);
  static const Color textTertiary = Color(0xFF64748B);
  static const Color textLightPrimary = Color(0xFF0F172A);
  static const Color textLightSecondary = Color(0xFF475569);

  // Borders & Feedback
  static const Color border = Color(0xFF243048);
  static const Color borderGlow = Color(0xFF00F0FF);
  static const Color error = Color(0xFFFF3366);
  static const Color success = Color(0xFF00E676);
  static const Color warning = Color(0xFFFFB703);

  // Overlays
  static const Color glassOverlay = Color(0xCC0B101B);
  static const Color controlsOverlay = Color(0xB3000000);
  static const Color pillOverlay = Color(0x66000000);
}
