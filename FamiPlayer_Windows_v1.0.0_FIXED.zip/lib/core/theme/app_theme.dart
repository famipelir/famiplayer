import 'package:flutter/material.dart';
import 'app_colors.dart';
import 'app_typography.dart';

enum ThemeModeOption { dark, amoled, light, system }
enum AccentColorOption { cyan, amber, emerald, violet }

class AppTheme {
  static Color getAccentColor(AccentColorOption option) {
    switch (option) {
      case AccentColorOption.cyan:
        return AppColors.cyanPrimary;
      case AccentColorOption.amber:
        return AppColors.amberPrimary;
      case AccentColorOption.emerald:
        return AppColors.emeraldPrimary;
      case AccentColorOption.violet:
        return AppColors.violetPrimary;
    }
  }

  static Color getAccentGlow(AccentColorOption option) {
    switch (option) {
      case AccentColorOption.cyan:
        return AppColors.cyanGlow;
      case AccentColorOption.amber:
        return AppColors.amberGlow;
      case AccentColorOption.emerald:
        return AppColors.emeraldGlow;
      case AccentColorOption.violet:
        return AppColors.violetGlow;
    }
  }

  static ThemeData getThemeData({
    required ThemeModeOption mode,
    required AccentColorOption accent,
    required bool isRtl,
    required Brightness systemBrightness,
  }) {
    final bool isDark = mode == ThemeModeOption.dark ||
        mode == ThemeModeOption.amoled ||
        (mode == ThemeModeOption.system && systemBrightness == Brightness.dark);

    final bool isAmoled = mode == ThemeModeOption.amoled;
    final Color primaryAccent = getAccentColor(accent);

    final Color bgColor = isDark
        ? (isAmoled ? AppColors.amoledBackground : AppColors.obsidian)
        : AppColors.lightBackground;

    final Color surfaceColor = isDark
        ? (isAmoled ? AppColors.amoledSurface : AppColors.surface)
        : AppColors.lightSurface;

    final Color cardColor = isDark ? AppColors.surfaceCard : AppColors.lightSurfaceCard;
    final Color borderColor = isDark ? AppColors.border : AppColors.lightBorder;

    return ThemeData(
      useMaterial3: true,
      brightness: isDark ? Brightness.dark : Brightness.light,
      scaffoldBackgroundColor: bgColor,
      colorScheme: ColorScheme(
        brightness: isDark ? Brightness.dark : Brightness.light,
        primary: primaryAccent,
        onPrimary: Colors.black,
        secondary: primaryAccent,
        onSecondary: Colors.black,
        error: AppColors.error,
        onError: Colors.white,
        surface: surfaceColor,
        onSurface: isDark ? AppColors.textPrimary : AppColors.textLightPrimary,
        outline: borderColor,
      ),
      cardTheme: CardTheme(
        color: cardColor,
        elevation: 0,
        shape: RoundedCornerShape(16.0, borderColor),
      ),
      dialogTheme: DialogTheme(
        backgroundColor: AppColors.surfaceModal,
        elevation: 16,
        shape: RoundedCornerShape(24.0, borderColor),
      ),
      textTheme: AppTypography.getTextTheme(isRtl: isRtl, isDark: isDark),
      sliderTheme: SliderThemeData(
        activeTrackColor: primaryAccent,
        inactiveTrackColor: Colors.white.withOpacity(0.24),
        thumbColor: primaryAccent,
        trackHeight: 4.0,
        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6.0),
        overlayShape: const RoundSliderOverlayShape(overlayRadius: 14.0),
      ),
      scrollbarTheme: ScrollbarThemeData(
        thumbColor: MaterialStateProperty.all(borderColor.withOpacity(0.8)),
        radius: const Radius.circular(8),
        thickness: MaterialStateProperty.all(6),
      ),
    );
  }
}

class RoundedCornerShape extends RoundedRectangleBorder {
  RoundedCornerShape(double radius, Color borderColor)
      : super(
          borderRadius: BorderRadius.circular(radius),
          side: BorderSide(color: borderColor, width: 1.0),
        );
}
