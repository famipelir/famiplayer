import 'dart:math';

class Formatters {
  static String formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    final seconds = duration.inSeconds.remainder(60);

    if (hours > 0) {
      return '$hours:${twoDigits(minutes)}:${twoDigits(seconds)}';
    } else {
      return '${twoDigits(minutes)}:${twoDigits(seconds)}';
    }
  }

  static String formatFileSize(int bytes) {
    if (bytes <= 0) return '0 B';
    const suffixes = ['B', 'KB', 'MB', 'GB', 'TB'];
    final i = (log(bytes) / log(1024)).floor();
    final size = bytes / pow(1024, i);
    return '${size.toStringAsFixed(1)} ${suffixes[i]}';
  }

  static String formatResolution(int width, int height) {
    if (width <= 0 || height <= 0) return '';
    if (width >= 3840 || height >= 2160) return '4K UHD';
    if (width >= 2560 || height >= 1440) return '2K QHD';
    if (width >= 1920 || height >= 1080) return '1080p FHD';
    if (width >= 1280 || height >= 720) return '720p HD';
    return '${width}x$height';
  }
}
