import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class FileUtils {
  static Future<Directory> getAppSupportDirectory() async {
    final appDir = await getApplicationSupportDirectory();
    final famiDir = Directory(p.join(appDir.path, 'FamiPlayer'));
    if (!await famiDir.exists()) {
      await famiDir.create(recursive: true);
    }
    return famiDir;
  }

  static Future<Directory> getThumbnailsDirectory() async {
    final appDir = await getAppSupportDirectory();
    final thumbDir = Directory(p.join(appDir.path, 'thumbnails'));
    if (!await thumbDir.exists()) {
      await thumbDir.create(recursive: true);
    }
    return thumbDir;
  }

  static Future<Directory> getVaultDirectory() async {
    final appDir = await getAppSupportDirectory();
    final vaultDir = Directory(p.join(appDir.path, 'vault_storage'));
    if (!await vaultDir.exists()) {
      await vaultDir.create(recursive: true);
    }
    return vaultDir;
  }

  static Future<Directory> getScreenshotsDirectory() async {
    try {
      final pictures = await getDownloadsDirectory() ?? await getApplicationDocumentsDirectory();
      final screenshotsDir = Directory(p.join(pictures.parent.path, 'Pictures', 'FamiPlayer'));
      if (!await screenshotsDir.exists()) {
        await screenshotsDir.create(recursive: true);
      }
      return screenshotsDir;
    } catch (_) {
      final fallback = await getApplicationDocumentsDirectory();
      return fallback;
    }
  }

  static String getFileNameWithoutExt(String path) {
    return p.basenameWithoutExtension(path);
  }

  static String getFileExtension(String path) {
    return p.extension(path).toLowerCase();
  }
}
