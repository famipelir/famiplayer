import 'dart:io';
import 'package:path/path.dart' as p;
import '../constants/app_constants.dart';

enum MediaType { video, audio, photo, url, unknown }

class MediaTypeDetector {
  static MediaType detectFromFilePath(String filePath) {
    final ext = p.extension(filePath).toLowerCase();
    if (AppConstants.supportedVideoExtensions.contains(ext)) {
      return MediaType.video;
    }
    if (AppConstants.supportedAudioExtensions.contains(ext)) {
      return MediaType.audio;
    }
    if (AppConstants.supportedImageExtensions.contains(ext)) {
      return MediaType.photo;
    }
    return MediaType.unknown;
  }

  static MediaType detectFromUrl(String url) {
    final cleanUrl = url.trim().toLowerCase();
    if (cleanUrl.startsWith('http://') || cleanUrl.startsWith('https://') || cleanUrl.startsWith('rtsp://')) {
      if (cleanUrl.endsWith('.m3u8') ||
          cleanUrl.contains('m3u8') ||
          cleanUrl.endsWith('.mp4') ||
          cleanUrl.endsWith('.webm') ||
          cleanUrl.endsWith('.mkv') ||
          cleanUrl.endsWith('.ts')) {
        return MediaType.video;
      }
      if (cleanUrl.endsWith('.mp3') ||
          cleanUrl.endsWith('.aac') ||
          cleanUrl.endsWith('.flac') ||
          cleanUrl.endsWith('.ogg')) {
        return MediaType.audio;
      }
      return MediaType.url;
    }
    return MediaType.unknown;
  }

  static bool isPlayableMedia(String filePath) {
    final type = detectFromFilePath(filePath);
    return type == MediaType.video || type == MediaType.audio;
  }

  static bool isVideo(String filePath) => detectFromFilePath(filePath) == MediaType.video;
  static bool isAudio(String filePath) => detectFromFilePath(filePath) == MediaType.audio;
  static bool isPhoto(String filePath) => detectFromFilePath(filePath) == MediaType.photo;
}
