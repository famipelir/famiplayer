import 'package:flutter/services.dart';

class ShortcutIntentItem {
  final LogicalKeySet keySet;
  final String labelKey;
  final String description;

  const ShortcutIntentItem({
    required this.keySet,
    required this.labelKey,
    required this.description,
  });
}

class AppShortcuts {
  static final Map<LogicalKeySet, String> defaultShortcuts = {
    LogicalKeySet(LogicalKeyboardKey.space): 'Play / Pause',
    LogicalKeySet(LogicalKeyboardKey.arrowLeft): 'Seek Backward 5s',
    LogicalKeySet(LogicalKeyboardKey.arrowRight): 'Seek Forward 5s',
    LogicalKeySet(LogicalKeyboardKey.arrowUp): 'Volume Up',
    LogicalKeySet(LogicalKeyboardKey.arrowDown): 'Volume Down',
    LogicalKeySet(LogicalKeyboardKey.keyF): 'Toggle Fullscreen',
    LogicalKeySet(LogicalKeyboardKey.keyM): 'Toggle Mute',
    LogicalKeySet(LogicalKeyboardKey.escape): 'Exit Fullscreen',
    LogicalKeySet(LogicalKeyboardKey.control, LogicalKeyboardKey.keyO): 'Open Local File',
    LogicalKeySet(LogicalKeyboardKey.control, LogicalKeyboardKey.keyL): 'Play Network URL',
    LogicalKeySet(LogicalKeyboardKey.control, LogicalKeyboardKey.keyF): 'Global Search',
    LogicalKeySet(LogicalKeyboardKey.control, LogicalKeyboardKey.keyP): 'Show Playlist',
    LogicalKeySet(LogicalKeyboardKey.bracketLeft): 'Decrease Speed',
    LogicalKeySet(LogicalKeyboardKey.bracketRight): 'Increase Speed',
  };
}
