class AppConstants {
  static const String appName = 'Fami Player';
  static const String appVersion = '1.0.0';
  static const String packageId = 'com.fami.player';
  static const String supportEmail = 'famipelir@gmail.com';

  // Window Sizes
  static const double minWindowWidth = 960.0;
  static const double minWindowHeight = 600.0;
  static const double defaultWindowWidth = 1280.0;
  static const double defaultWindowHeight = 800.0;

  // Player Defaults
  static const List<double> playbackSpeeds = [
    0.25,
    0.5,
    0.75,
    1.0,
    1.25,
    1.5,
    1.75,
    2.0,
    2.5,
    3.0,
    4.0,
  ];

  static const List<int> equalizerFrequencies = [
    31,
    62,
    125,
    250,
    500,
    1000,
    2000,
    4000,
    8000,
    16000,
  ];

  static const List<String> supportedVideoExtensions = [
    '.mp4',
    '.mkv',
    '.webm',
    '.mov',
    '.avi',
    '.mpeg',
    '.mpg',
    '.ts',
    '.m4v',
    '.flv',
    '.wmv',
    '.3gp',
  ];

  static const List<String> supportedAudioExtensions = [
    '.mp3',
    '.aac',
    '.wav',
    '.flac',
    '.m4a',
    '.ogg',
    '.wma',
    '.opus',
  ];

  static const List<String> supportedImageExtensions = [
    '.jpg',
    '.jpeg',
    '.png',
    '.webp',
    '.bmp',
    '.gif',
  ];

  static const List<String> supportedSubtitleExtensions = [
    '.srt',
    '.vtt',
    '.ass',
    '.ssa',
  ];
}
