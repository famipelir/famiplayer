import 'package:flutter/material.dart';
import 'strings_en.dart';
import 'strings_fa.dart';
import 'strings_ar.dart';

enum AppLanguage {
  english('en', 'English', false),
  persian('fa', 'فارسی', true),
  arabic('ar', 'العربية', true);

  final String code;
  final String displayName;
  final bool isRtl;

  const AppLanguage(this.code, this.displayName, this.isRtl);

  static AppLanguage fromCode(String code) {
    return AppLanguage.values.firstWhere(
      (lang) => lang.code == code,
      orElse: () => AppLanguage.english,
    );
  }
}

class AppLocalizations {
  final Locale locale;

  AppLocalizations(this.locale);

  static const List<Locale> supportedLocales = [
    Locale('en'),
    Locale('fa'),
    Locale('ar'),
  ];

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations) ??
        AppLocalizations(const Locale('en'));
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      AppLocalizationsDelegate();

  Map<String, String> get _strings {
    switch (locale.languageCode) {
      case 'fa':
        return StringsFa.values;
      case 'ar':
        return StringsAr.values;
      case 'en':
      default:
        return StringsEn.values;
    }
  }

  String translate(String key) {
    return _strings[key] ?? StringsEn.values[key] ?? key;
  }

  String get(String key) => translate(key);
}

class AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) =>
      ['en', 'fa', 'ar'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async {
    return AppLocalizations(locale);
  }

  @override
  bool shouldReload(AppLocalizationsDelegate old) => false;
}
