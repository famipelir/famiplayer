import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:media_kit/media_kit.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:window_manager/window_manager.dart';

import 'core/localization/app_localizations.dart';
import 'core/theme/app_colors.dart';
import 'core/theme/app_theme.dart';
import 'data/database/app_database.dart';
import 'data/models/media_item_model.dart';
import 'features/downloads/downloads_screen.dart';
import 'features/favorites/favorites_screen.dart';
import 'features/file_manager/file_manager_screen.dart';
import 'features/history/history_screen.dart';
import 'features/home/home_screen.dart';
import 'features/music/music_library_screen.dart';
import 'features/photos/photo_viewer_screen.dart';
import 'features/player/video_player_screen.dart';
import 'features/playlists/playlists_screen.dart';
import 'features/search/global_search_screen.dart';
import 'features/settings/settings_screen.dart';
import 'features/shortcuts/keyboard_shortcuts_screen.dart';
import 'features/url_player/play_url_screen.dart';
import 'features/vault/private_vault_screen.dart';
import 'features/videos/video_library_screen.dart';
import 'services/download_manager_service.dart';
import 'services/equalizer_service.dart';
import 'services/library_scanner_service.dart';
import 'services/media_engine_service.dart';
import 'shared/widgets/fami_sidebar.dart';
import 'shared/widgets/windows_title_bar.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();

  if (Platform.isWindows) {
    await windowManager.ensureInitialized();
    const windowOptions = WindowOptions(
      size: Size(1280, 800),
      minimumSize: Size(960, 600),
      center: true,
      backgroundColor: Colors.transparent,
      skipTaskbar: false,
      titleBarStyle: TitleBarStyle.hidden,
      title: 'Fami Player',
    );
    await windowManager.waitUntilReadyToShow(windowOptions, () async {
      await windowManager.show();
      await windowManager.focus();
    });
  }

  // Initialize SQLite database
  await AppDatabase.instance.database;

  runApp(const FamiPlayerApp());
}

class FamiPlayerApp extends StatefulWidget {
  const FamiPlayerApp({super.key});

  @override
  State<FamiPlayerApp> createState() => _FamiPlayerAppState();
}

class _FamiPlayerAppState extends State<FamiPlayerApp> {
  AppThemeMode _themeMode = AppThemeMode.obsidian;
  AppAccentColor _accentColor = AppAccentColor.cyan;
  Locale _locale = const Locale('en');

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    final langCode = prefs.getString('pref_language') ?? 'en';
    final themeIndex = prefs.getInt('pref_theme_mode') ?? AppThemeMode.obsidian.index;
    final accentIndex = prefs.getInt('pref_accent_color') ?? AppAccentColor.cyan.index;

    if (mounted) {
      setState(() {
        _locale = Locale(langCode);
        if (themeIndex >= 0 && themeIndex < AppThemeMode.values.length) {
          _themeMode = AppThemeMode.values[themeIndex];
        }
        if (accentIndex >= 0 && accentIndex < AppAccentColor.values.length) {
          _accentColor = AppAccentColor.values[accentIndex];
        }
      });
    }
  }

  Future<void> _setLocale(Locale loc) async {
    setState(() => _locale = loc);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('pref_language', loc.languageCode);
  }

  Future<void> _setThemeMode(AppThemeMode mode) async {
    setState(() => _themeMode = mode);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('pref_theme_mode', mode.index);
  }

  Future<void> _setAccentColor(AppAccentColor accent) async {
    setState(() => _accentColor = accent);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('pref_accent_color', accent.index);
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => MediaEngineService()),
        ChangeNotifierProxyProvider<MediaEngineService, EqualizerService>(
          create: (_) => EqualizerService(),
          update: (_, mediaEngine, eqService) =>
              (eqService ?? EqualizerService())..attachMediaEngine(mediaEngine),
        ),
        ChangeNotifierProvider(create: (_) => LibraryScannerService()),
        ChangeNotifierProvider(create: (_) => DownloadManagerService()),
      ],
      child: MaterialApp(
        title: 'Fami Player',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.build(
          mode: _themeMode,
          accent: _accentColor,
          fontFamily: _locale.languageCode == 'fa' || _locale.languageCode == 'ar'
              ? 'Vazirmatn'
              : 'Segoe UI',
        ),
        locale: _locale,
        supportedLocales: AppLocalizations.supportedLocales,
        localizationsDelegates: const [
          AppLocalizationsDelegate(),
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: FamiPlayerShell(
          currentThemeMode: _themeMode,
          currentAccentColor: _accentColor,
          currentLocale: _locale,
          onThemeModeChanged: _setThemeMode,
          onAccentColorChanged: _setAccentColor,
          onLocaleChanged: _setLocale,
        ),
      ),
    );
  }
}

class FamiPlayerShell extends StatefulWidget {
  final AppThemeMode currentThemeMode;
  final AppAccentColor currentAccentColor;
  final Locale currentLocale;
  final ValueChanged<AppThemeMode> onThemeModeChanged;
  final ValueChanged<AppAccentColor> onAccentColorChanged;
  final ValueChanged<Locale> onLocaleChanged;

  const FamiPlayerShell({
    super.key,
    required this.currentThemeMode,
    required this.currentAccentColor,
    required this.currentLocale,
    required this.onThemeModeChanged,
    required this.onAccentColorChanged,
    required this.onLocaleChanged,
  });

  @override
  State<FamiPlayerShell> createState() => _FamiPlayerShellState();
}

class _FamiPlayerShellState extends State<FamiPlayerShell> {
  NavDestination _currentDestination = NavDestination.home;
  bool _isSidebarCollapsed = false;
  MediaItemModel? _activePlayingMedia;
  bool _isPlayingFullscreenVideo = false;

  void _playMediaItem(MediaItemModel media) {
    setState(() {
      _activePlayingMedia = media;
      _isPlayingFullscreenVideo = true;
    });
  }

  void _playUrlDirectly(String url) {
    final engine = context.read<MediaEngineService>();
    engine.openUrl(url);
    setState(() {
      _isPlayingFullscreenVideo = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isPlayingFullscreenVideo) {
      return VideoPlayerScreen(
        initialMedia: _activePlayingMedia,
        onBack: () => setState(() => _isPlayingFullscreenVideo = false),
      );
    }

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: Column(
        children: [
          // Windows 11 Title Bar
          WindowsTitleBar(
            title: Text(
              'Fami Player — Native Windows Media Engine',
              style: TextStyle(
                fontSize: 12,
                color: AppColors.textSecondary.withOpacity(0.7),
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          // Main Body with Sidebar + Screen Content
          Expanded(
            child: Row(
              children: [
                // Navigation Sidebar
                FamiSidebar(
                  currentDestination: _currentDestination,
                  onDestinationSelected: (dest) => setState(() => _currentDestination = dest),
                  isCollapsed: _isSidebarCollapsed,
                  onToggleCollapse: () => setState(() => _isSidebarCollapsed = !_isSidebarCollapsed),
                ),
                // Primary Screen Viewport
                Expanded(
                  child: _buildScreenForDestination(_currentDestination),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScreenForDestination(NavDestination destination) {
    switch (destination) {
      case NavDestination.home:
        return HomeScreen(
          onNavigateToUrl: () => setState(() => _currentDestination = NavDestination.playUrl),
          onPlayMedia: _playMediaItem,
        );
      case NavDestination.videos:
        return VideoLibraryScreen(onPlayVideo: _playMediaItem);
      case NavDestination.music:
        return MusicLibraryScreen(onPlayMusic: _playMediaItem);
      case NavDestination.photos:
        return const PhotoViewerScreen();
      case NavDestination.playlists:
        return const PlaylistsScreen();
      case NavDestination.favorites:
        return FavoritesScreen(onPlayMedia: _playMediaItem);
      case NavDestination.history:
        return HistoryScreen(onPlayMedia: _playMediaItem);
      case NavDestination.downloads:
        return const DownloadsScreen();
      case NavDestination.playUrl:
        return PlayUrlScreen(onPlayUrl: _playUrlDirectly);
      case NavDestination.vault:
        return const PrivateVaultScreen();
      case NavDestination.fileManager:
        return FileManagerScreen(onPlayMedia: _playMediaItem);
      case NavDestination.settings:
        return SettingsScreen(
          currentThemeMode: widget.currentThemeMode,
          currentAccentColor: widget.currentAccentColor,
          currentLocale: widget.currentLocale,
          onThemeModeChanged: widget.onThemeModeChanged,
          onAccentColorChanged: widget.onAccentColorChanged,
          onLocaleChanged: widget.onLocaleChanged,
        );
    }
  }
}
