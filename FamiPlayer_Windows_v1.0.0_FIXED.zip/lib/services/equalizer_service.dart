import 'package:flutter/material.dart';
import '../core/constants/app_constants.dart';
import 'media_engine_service.dart';

enum EqualizerPreset {
  flat('Flat'),
  rock('Rock'),
  pop('Pop'),
  classical('Classical'),
  jazz('Jazz'),
  bassBoost('Bass Boost'),
  vocal('Vocal'),
  movie('Movie');

  final String displayName;
  const EqualizerPreset(this.displayName);
}

class EqualizerService extends ChangeNotifier {
  MediaEngineService? _mediaEngine;
  bool _isEnabled = true;
  EqualizerPreset _currentPreset = EqualizerPreset.flat;

  // Gains for 10 bands: 31Hz, 62Hz, 125Hz, 250Hz, 500Hz, 1kHz, 2kHz, 4kHz, 8kHz, 16kHz
  // Range: -12.0 dB to +12.0 dB
  List<double> _bandGains = List.filled(10, 0.0);

  bool get isEnabled => _isEnabled;
  EqualizerPreset get currentPreset => _currentPreset;
  List<double> get bandGains => List.unmodifiable(_bandGains);

  void attachMediaEngine(MediaEngineService engine) {
    _mediaEngine = engine;
    _syncToEngine();
  }

  void _syncToEngine() {
    _mediaEngine?.applyEqualizer(_bandGains, _isEnabled);
  }

  void toggleEnabled(bool val) {
    _isEnabled = val;
    _syncToEngine();
    notifyListeners();
  }

  void setBandGain(int index, double gainDb) {
    if (index >= 0 && index < 10) {
      _bandGains[index] = gainDb.clamp(-12.0, 12.0);
      _currentPreset = EqualizerPreset.flat; // Switched to custom
      _syncToEngine();
      notifyListeners();
    }
  }

  void applyPreset(EqualizerPreset preset) {
    _currentPreset = preset;
    switch (preset) {
      case EqualizerPreset.flat:
        _bandGains = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        break;
      case EqualizerPreset.rock:
        _bandGains = [4.5, 3.0, 1.5, 0.0, -1.0, -0.5, 1.5, 3.0, 4.0, 4.5];
        break;
      case EqualizerPreset.pop:
        _bandGains = [-1.0, 1.0, 3.0, 4.0, 3.5, 1.5, 0.0, 1.0, 2.5, 3.0];
        break;
      case EqualizerPreset.classical:
        _bandGains = [4.0, 3.0, 2.5, 2.0, -1.0, -1.0, 0.0, 2.0, 3.0, 3.5];
        break;
      case EqualizerPreset.jazz:
        _bandGains = [3.0, 2.0, 0.0, 2.0, -1.5, -1.5, 0.0, 1.5, 3.0, 3.5];
        break;
      case EqualizerPreset.bassBoost:
        _bandGains = [7.0, 5.5, 4.0, 2.0, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0];
        break;
      case EqualizerPreset.vocal:
        _bandGains = [-2.0, -2.0, 0.0, 2.5, 4.5, 4.0, 3.0, 1.0, 0.0, -1.0];
        break;
      case EqualizerPreset.movie:
        _bandGains = [5.0, 3.5, 1.0, 0.0, -1.0, 2.0, 3.5, 4.0, 4.5, 5.0];
        break;
    }
    _syncToEngine();
    notifyListeners();
  }

  void reset() {
    applyPreset(EqualizerPreset.flat);
  }
}

