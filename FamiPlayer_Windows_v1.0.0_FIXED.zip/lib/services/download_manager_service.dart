import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../data/models/playlist_model.dart';

class DownloadManagerService extends ChangeNotifier {
  final List<DownloadTaskModel> _tasks = [];
  final Map<String, http.Client> _activeClients = {};

  List<DownloadTaskModel> get tasks => List.unmodifiable(_tasks);

  Future<void> startDownload(String url) async {
    final cleanUrl = url.trim();
    if (cleanUrl.isEmpty) return;

    final fileName = p.basename(Uri.parse(cleanUrl).path);
    final finalFileName = fileName.isEmpty ? 'media_${DateTime.now().millisecondsSinceEpoch}.mp4' : fileName;

    final downloadsDir = await getDownloadsDirectory() ?? await getApplicationDocumentsDirectory();
    final destinationPath = p.join(downloadsDir.path, finalFileName);

    final task = DownloadTaskModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      url: cleanUrl,
      destinationPath: destinationPath,
      fileName: finalFileName,
      status: DownloadStatus.downloading,
      createdAt: DateTime.now(),
    );

    _tasks.insert(0, task);
    notifyListeners();

    _executeDownload(task);
  }

  Future<void> _executeDownload(DownloadTaskModel task) async {
    final client = http.Client();
    _activeClients[task.id] = client;

    try {
      final request = http.Request('GET', Uri.parse(task.url));
      final response = await client.send(request);

      if (response.statusCode >= 200 && response.statusCode < 300) {
        final totalBytes = response.contentLength ?? 0;
        final file = File(task.destinationPath);
        final sink = file.openWrite();
        int downloaded = 0;

        await response.stream.listen((chunk) {
          downloaded += chunk.length;
          sink.add(chunk);

          final index = _tasks.indexWhere((t) => t.id == task.id);
          if (index != -1) {
            _tasks[index] = DownloadTaskModel(
              id: task.id,
              url: task.url,
              destinationPath: task.destinationPath,
              fileName: task.fileName,
              totalBytes: totalBytes,
              downloadedBytes: downloaded,
              status: DownloadStatus.downloading,
              createdAt: task.createdAt,
            );
            notifyListeners();
          }
        }).asFuture();

        await sink.flush();
        await sink.close();

        _updateTaskStatus(task.id, DownloadStatus.completed);
      } else {
        _updateTaskStatus(task.id, DownloadStatus.failed, error: 'HTTP ${response.statusCode}');
      }
    } catch (e) {
      _updateTaskStatus(task.id, DownloadStatus.failed, error: e.toString());
    } finally {
      _activeClients.remove(task.id);
    }
  }

  void cancelDownload(String taskId) {
    _activeClients[taskId]?.close();
    _activeClients.remove(taskId);
    _updateTaskStatus(taskId, DownloadStatus.cancelled);
  }

  void _updateTaskStatus(String taskId, DownloadStatus status, {String? error}) {
    final index = _tasks.indexWhere((t) => t.id == taskId);
    if (index != -1) {
      final t = _tasks[index];
      _tasks[index] = DownloadTaskModel(
        id: t.id,
        url: t.url,
        destinationPath: t.destinationPath,
        fileName: t.fileName,
        totalBytes: t.totalBytes,
        downloadedBytes: t.downloadedBytes,
        status: status,
        errorMessage: error,
        createdAt: t.createdAt,
      );
      notifyListeners();
    }
  }
}
