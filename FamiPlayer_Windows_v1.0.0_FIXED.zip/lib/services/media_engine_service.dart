import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:path/path.dart' as p;
import '../core/constants/app_constants.dart';
import '../core/utils/file_utils.dart';
import '../core/utils/media_type_detector.dart';
import '../data/database/app_database.dart';
import '../data/models/media_item_model.dart';

enum VideoAspectRatio { fit, stretch, fill, original }

class MediaEngineService extends ChangeNotifier {
  late final Player player;
  late final VideoController videoController;

  MediaItemModel? _currentMedia;
  bool _isPlaying = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  Duration _buffer = Duration.zero;
  double _volume = 100.0;
  double _rate = 1.0;
  bool _isMuted = false;
  VideoAspectRatio _aspectRatio = VideoAspectRatio.fit;

  // A-B Loop
  Duration? _loopPointA;
  Duration? _loopPointB;
  bool _isAbLoopActive = false;

  // Subtitles & Audio Tracks
  List<SubtitleTrack> _subtitles = [];
  SubtitleTrack _selectedSubtitle = SubtitleTrack.no();
  List<AudioTrack> _audioTracks = [];
  AudioTrack _selectedAudioTrack = AudioTrack.auto();

  // Equalizer Configuration (10-band)
  bool _equalizerEnabled = true;
  List<double> _equalizerGains = List.filled(10, 0.0);

  StreamSubscription? _posSub;
  StreamSubscription? _durSub;
  StreamSubscription? _playSub;
  StreamSubscription? _bufSub;
  StreamSubscription? _tracksSub;

  MediaItemModel? get currentMedia => _currentMedia;
  bool get isPlaying => _isPlaying;
  Duration get position => _position;
  Duration get duration => _duration;
  Duration get buffer => _buffer;
  double get volume => _volume;
  double get rate => _rate;
  bool get isMuted => _isMuted;
  VideoAspectRatio get aspectRatio => _aspectRatio;
  Duration? get loopPointA => _loopPointA;
  Duration? get loopPointB => _loopPointB;
  bool get isAbLoopActive => _isAbLoopActive;
  List<SubtitleTrack> get subtitles => _subtitles;
  SubtitleTrack get selectedSubtitle => _selectedSubtitle;
  List<AudioTrack> get audioTracks => _audioTracks;
  AudioTrack get selectedAudioTrack => _selectedAudioTrack;
  bool get equalizerEnabled => _equalizerEnabled;
  List<double> get equalizerGains => List.unmodifiable(_equalizerGains);

  MediaEngineService() {
    MediaKit.ensureInitialized();
    player = Player(
      configuration: const PlayerConfiguration(
        title: 'Fami Player Engine',
        ready: null,
      ),
    );
    videoController = VideoController(player);

    _initSubscriptions();
  }

  void _initSubscriptions() {
    _posSub = player.stream.position.listen((pos) {
      _position = pos;
      _checkAbLoop(pos);
      notifyListeners();
    });

    _durSub = player.stream.duration.listen((dur) {
      _duration = dur;
      notifyListeners();
    });

    _playSub = player.stream.playing.listen((playing) {
      _isPlaying = playing;
      notifyListeners();
    });

    _bufSub = player.stream.buffer.listen((buf) {
      _buffer = buf;
      notifyListeners();
    });

    _tracksSub = player.stream.tracks.listen((tracks) {
      _subtitles = tracks.subtitle;
      _audioTracks = tracks.audio;
      notifyListeners();
    });
  }

  void _checkAbLoop(Duration currentPos) {
    if (_isAbLoopActive && _loopPointA != null && _loopPointB != null) {
      if (currentPos >= _loopPointB!) {
        player.seek(_loopPointA!);
      }
    }
  }

  Future<void> openMedia(MediaItemModel media, {bool startFromBeginning = false}) async {
    _currentMedia = media;
    clearAbLoop();

    final playable = Media(media.path);
    await player.open(playable, play: true);

    if (!startFromBeginning && media.lastPlayedPositionMs > 5000) {
      await player.seek(Duration(milliseconds: media.lastPlayedPositionMs));
    }

    notifyListeners();
  }

  Future<void> openUrl(String url) async {
    final cleanUrl = url.trim();
    final type = MediaTypeDetector.detectFromUrl(cleanUrl);
    final media = MediaItemModel(
      id: cleanUrl.hashCode.toString(),
      path: cleanUrl,
      title: cleanUrl.split('/').last.split('?').first,
      mediaType: type,
      dateAdded: DateTime.now(),
    );

    _currentMedia = media;
    clearAbLoop();

    final playable = Media(cleanUrl);
    await player.open(playable, play: true);
    notifyListeners();
  }

  Future<void> play() async => await player.play();
  Future<void> pause() async {
    await player.pause();
    _saveCurrentPlaybackPosition();
  }

  Future<void> playOrPause() async {
    if (_isPlaying) {
      await pause();
    } else {
      await play();
    }
  }

  Future<void> seek(Duration pos) async => await player.seek(pos);

  Future<void> seekRelative(int seconds) async {
    final target = _position + Duration(seconds: seconds);
    if (target < Duration.zero) {
      await seek(Duration.zero);
    } else if (target > _duration) {
      await seek(_duration);
    } else {
      await seek(target);
    }
  }

  Future<void> stepFrameForward() async {
    await pause();
    final target = _position + const Duration(milliseconds: 42); // approx 24fps
    if (target <= _duration) {
      await seek(target);
    }
  }

  Future<void> stepFrameBackward() async {
    await pause();
    final target = _position - const Duration(milliseconds: 42);
    if (target >= Duration.zero) {
      await seek(target);
    }
  }

  Future<String?> takeScreenshot() async {
    try {
      final Uint8List? rawBytes = await player.screenshot();
      if (rawBytes != null && rawBytes.isNotEmpty) {
        final screenshotsDir = await FileUtils.getScreenshotsDirectory();
        final timestamp = DateTime.now().millisecondsSinceEpoch;
        final fileName = 'fami_screenshot_$timestamp.png';
        final file = File(p.join(screenshotsDir.path, fileName));
        await file.writeAsBytes(rawBytes);
        return file.path;
      }
    } catch (_) {
      // Fallback
    }
    return null;
  }

  Future<void> setVolume(double val) async {
    _volume = val.clamp(0.0, 100.0);
    await player.setVolume(_volume);
    notifyListeners();
  }

  Future<void> toggleMute() async {
    _isMuted = !_isMuted;
    if (_isMuted) {
      await player.setVolume(0);
    } else {
      await player.setVolume(_volume);
    }
    notifyListeners();
  }

  Future<void> setPlaybackSpeed(double speed) async {
    _rate = speed;
    await player.setRate(speed);
    notifyListeners();
  }

  void setAspectRatio(VideoAspectRatio ratio) {
    _aspectRatio = ratio;
    notifyListeners();
  }

  Future<void> setSubtitleTrack(SubtitleTrack track) async {
    _selectedSubtitle = track;
    await player.setSubtitleTrack(track);
    notifyListeners();
  }

  Future<void> setAudioTrack(AudioTrack track) async {
    _selectedAudioTrack = track;
    await player.setAudioTrack(track);
    notifyListeners();
  }

  // 10-Band Equalizer Engine Integration (libmpv lavfi equalizer filter chain)
  Future<void> applyEqualizer(List<double> gains, bool enabled) async {
    _equalizerGains = List.from(gains);
    _equalizerEnabled = enabled;

    try {
      final dynamic platform = player.platform;
      if (platform != null) {
        if (!enabled) {
          await platform.setProperty('af', '');
        } else {
          const freqs = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
          final filterList = <String>[];
          for (int i = 0; i < 10 && i < gains.length; i++) {
            final g = gains[i].clamp(-12.0, 12.0);
            filterList.add('equalizer=f=${freqs[i]}:width_type=o:w=1:g=${g.toStringAsFixed(1)}');
          }
          final afFilter = 'lavfi=[${filterList.join(',')}]';
          await platform.setProperty('af', afFilter);
        }
      }
    } catch (_) {
      // Fallback if platform does not expose setProperty on specific platform mocks
    }
    notifyListeners();
  }

  // A-B Loop
  void setLoopPointA() {
    _loopPointA = _position;
    if (_loopPointB != null && _loopPointB! > _loopPointA!) {
      _isAbLoopActive = true;
    }
    notifyListeners();
  }

  void setLoopPointB() {
    if (_loopPointA != null && _position > _loopPointA!) {
      _loopPointB = _position;
      _isAbLoopActive = true;
      notifyListeners();
    }
  }

  void clearAbLoop() {
    _loopPointA = null;
    _loopPointB = null;
    _isAbLoopActive = false;
    notifyListeners();
  }

  void _saveCurrentPlaybackPosition() {
    if (_currentMedia != null && _position.inMilliseconds > 2000) {
      AppDatabase.instance.updatePlaybackPosition(
        _currentMedia!.id,
        _position.inMilliseconds,
      );
    }
  }

  @override
  void dispose() {
    _saveCurrentPlaybackPosition();
    _posSub?.cancel();
    _durSub?.cancel();
    _playSub?.cancel();
    _bufSub?.cancel();
    _tracksSub?.cancel();
    player.dispose();
    super.dispose();
  }
}
