import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import '../core/constants/app_constants.dart';
import '../core/utils/media_type_detector.dart';
import '../data/database/app_database.dart';
import '../data/models/media_item_model.dart';

class LibraryScannerService extends ChangeNotifier {
  bool _isScanning = false;
  int _scannedFilesCount = 0;
  String _currentScanningPath = '';

  bool get isScanning => _isScanning;
  int get scannedFilesCount => _scannedFilesCount;
  String get currentScanningPath => _currentScanningPath;

  Future<void> scanFolder(String folderPath) async {
    final dir = Directory(folderPath);
    if (!await dir.exists()) return;

    _isScanning = true;
    _scannedFilesCount = 0;
    _currentScanningPath = folderPath;
    notifyListeners();

    try {
      await AppDatabase.instance.addMonitoredFolder(folderPath);
      await _scanDirectoryRecursive(dir);
    } catch (e) {
      debugPrint('Error scanning folder $folderPath: $e');
    } finally {
      _isScanning = false;
      _currentScanningPath = '';
      notifyListeners();
    }
  }

  Future<void> scanAllMonitoredFolders() async {
    final folders = await AppDatabase.instance.getMonitoredFolders();
    for (final folder in folders) {
      await scanFolder(folder);
    }
  }

  Future<void> _scanDirectoryRecursive(Directory directory) async {
    try {
      final entities = directory.listSync(recursive: true, followLinks: false);
      for (final entity in entities) {
        if (entity is File) {
          final filePath = entity.path;
          final ext = p.extension(filePath).toLowerCase();

          if (AppConstants.supportedVideoExtensions.contains(ext) ||
              AppConstants.supportedAudioExtensions.contains(ext) ||
              AppConstants.supportedImageExtensions.contains(ext)) {
            final stat = await entity.stat();
            final type = MediaTypeDetector.detectFromFilePath(filePath);
            final title = p.basenameWithoutExtension(filePath);

            final media = MediaItemModel(
              id: filePath.hashCode.toString(),
              path: filePath,
              title: title,
              mediaType: type,
              fileSizeBytes: stat.size,
              dateAdded: stat.modified,
            );

            await AppDatabase.instance.insertMediaItem(media);
            _scannedFilesCount++;
            notifyListeners();
          }
        }
      }
    } catch (e) {
      debugPrint('Failed reading directory ${directory.path}: $e');
    }
  }
}
